# China Bazar

A production-ready, full-stack e-commerce website built with React, TypeScript, Vite, Tailwind CSS, and Supabase.

## Features

### Customer Features
- Browse products by category
- Search and filter products
- Product detail pages with reviews
- Shopping cart with persistent storage
- Cash on Delivery checkout
- Order tracking
- Contact form
- FAQ section
- Responsive design

### Admin Features
- Secure admin authentication
- Dashboard with statistics
- Product management (CRUD + image upload)
- Category management
- Order management with status updates
- Banner management
- Review moderation
- FAQ management
- Website settings

## Tech Stack

- **Frontend:** React 18 + TypeScript + Vite
- **Styling:** Tailwind CSS
- **Backend:** Supabase (PostgreSQL + Auth + Storage)
- **State Management:** Zustand (cart), React Query (server state)
- **Routing:** React Router v6
- **Icons:** Lucide React

## Setup

### 1. Install Dependencies

```bash
npm install
```

### 2. Configure Environment Variables

Create a `.env` file:

```env
VITE_SUPABASE_URL=https://your-project.supabase.co
VITE_SUPABASE_ANON_KEY=your-anon-key
```

### 3. Run Database Migration

Open the Supabase SQL Editor and run the contents of `supabase/migrations/001_initial_schema.sql`.

### 4. Create Storage Bucket

In Supabase Dashboard:
- Go to Storage
- Create a new bucket named `products`
- Set it as a public bucket

### 5. Add Supabase Functions

Run these in the SQL Editor:

```sql
CREATE OR REPLACE FUNCTION decrement_stock(product_id UUID, quantity INTEGER)
RETURNS VOID AS $$
BEGIN
  UPDATE products SET stock_quantity = stock_quantity - quantity WHERE id = product_id;
END;
$$ LANGUAGE plpgsql;

CREATE OR REPLACE FUNCTION increment_view_count(product_id UUID)
RETURNS VOID AS $$
BEGIN
  UPDATE products SET view_count = view_count + 1 WHERE id = product_id;
END;
$$ LANGUAGE plpgsql;
```

### 6. Create Admin User

1. Sign up a user through Supabase Auth (or use the signup API)
2. Insert the user into the admin_users table:

```sql
INSERT INTO admin_users (id, email, full_name, role, is_active)
VALUES ('user-uuid-from-auth', 'admin@email.com', 'Admin User', 'admin', true);
```

### 7. Start Development Server

```bash
npm run dev
```

### 8. Build for Production

```bash
npm run build
```

## Deployment

### Vercel

1. Push code to GitHub
2. Connect repository to Vercel
3. Add environment variables in Vercel dashboard
4. Deploy

## Project Structure

```
china-bazar/
├── src/
│   ├── components/
│   │   ├── customer/       # Customer-facing components
│   │   ├── admin/           # Admin components
│   │   ├── layouts/         # Layout components
│   │   └── ProtectedRoute.tsx
│   ├── contexts/
│   │   ├── AuthContext.tsx
│   │   └── CartContext.tsx
│   ├── lib/
│   │   ├── supabase.ts
│   │   ├── database.types.ts
│   │   └── utils.ts
│   ├── pages/
│   │   ├── customer/        # Customer pages
│   │   └── admin/           # Admin pages
│   ├── types/
│   │   └── index.ts
│   ├── App.tsx
│   ├── main.tsx
│   └── index.css
├── supabase/
│   └── migrations/
│       └── 001_initial_schema.sql
├── package.json
├── vite.config.ts
├── tailwind.config.js
└── tsconfig.json
```

## License

MIT
