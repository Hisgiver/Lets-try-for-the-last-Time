import { BrowserRouter, Routes, Route } from 'react-router-dom'
import { HelmetProvider } from 'react-helmet-async'
import { Toaster } from 'react-hot-toast'
import { AuthProvider } from '@/contexts/AuthContext'
import { QueryClient, QueryClientProvider } from '@tanstack/react-query'

// Layouts
import MainLayout from '@/components/layouts/MainLayout'
import AdminLayout from '@/components/layouts/AdminLayout'

// Customer Pages
import HomePage from '@/pages/customer/HomePage'
import ShopPage from '@/pages/customer/ShopPage'
import ProductPage from '@/pages/customer/ProductPage'
import CartPage from '@/pages/customer/CartPage'
import CheckoutPage from '@/pages/customer/CheckoutPage'
import OrderSuccessPage from '@/pages/customer/OrderSuccessPage'
import ContactPage from '@/pages/customer/ContactPage'
import FAQPage from '@/pages/customer/FAQPage'
import PrivacyPolicyPage from '@/pages/customer/PrivacyPolicyPage'
import TermsPage from '@/pages/customer/TermsPage'
import ReturnPolicyPage from '@/pages/customer/ReturnPolicyPage'
import ShippingPolicyPage from '@/pages/customer/ShippingPolicyPage'

// Admin Pages
import AdminLoginPage from '@/pages/admin/AdminLoginPage'
import AdminDashboardPage from '@/pages/admin/AdminDashboardPage'
import AdminProductsPage from '@/pages/admin/AdminProductsPage'
import AdminCategoriesPage from '@/pages/admin/AdminCategoriesPage'
import AdminOrdersPage from '@/pages/admin/AdminOrdersPage'
import AdminBannersPage from '@/pages/admin/AdminBannersPage'
import AdminReviewsPage from '@/pages/admin/AdminReviewsPage'
import AdminSettingsPage from '@/pages/admin/AdminSettingsPage'
import AdminFAQsPage from '@/pages/admin/AdminFAQsPage'

// Protected Route
import ProtectedRoute from '@/components/ProtectedRoute'

const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      staleTime: 5 * 60 * 1000,
      retry: 1,
    },
  },
})

function App() {
  return (
    <HelmetProvider>
      <QueryClientProvider client={queryClient}>
        <AuthProvider>
          <BrowserRouter>
            <Toaster
              position="top-right"
              toastOptions={{
                duration: 3000,
                style: {
                  background: '#14532d',
                  color: '#fff',
                },
              }}
            />
            <Routes>
              {/* Customer Routes */}
              <Route element={<MainLayout />}>
                <Route path="/" element={<HomePage />} />
                <Route path="/shop" element={<ShopPage />} />
                <Route path="/product/:slug" element={<ProductPage />} />
                <Route path="/cart" element={<CartPage />} />
                <Route path="/checkout" element={<CheckoutPage />} />
                <Route path="/order-success/:orderId" element={<OrderSuccessPage />} />
                <Route path="/contact" element={<ContactPage />} />
                <Route path="/faq" element={<FAQPage />} />
                <Route path="/privacy-policy" element={<PrivacyPolicyPage />} />
                <Route path="/terms-conditions" element={<TermsPage />} />
                <Route path="/return-policy" element={<ReturnPolicyPage />} />
                <Route path="/shipping-policy" element={<ShippingPolicyPage />} />
              </Route>

              {/* Admin Routes */}
              <Route path="/admin/login" element={<AdminLoginPage />} />
              <Route element={<ProtectedRoute />}>
                <Route element={<AdminLayout />}>
                  <Route path="/admin" element={<AdminDashboardPage />} />
                  <Route path="/admin/products" element={<AdminProductsPage />} />
                  <Route path="/admin/categories" element={<AdminCategoriesPage />} />
                  <Route path="/admin/orders" element={<AdminOrdersPage />} />
                  <Route path="/admin/banners" element={<AdminBannersPage />} />
                  <Route path="/admin/reviews" element={<AdminReviewsPage />} />
                  <Route path="/admin/settings" element={<AdminSettingsPage />} />
                  <Route path="/admin/faqs" element={<AdminFAQsPage />} />
                </Route>
              </Route>
            </Routes>
          </BrowserRouter>
        </AuthProvider>
      </QueryClientProvider>
    </HelmetProvider>
  )
}

export default App
