import { useAuth } from '@/contexts/AuthContext'
import { Bell, User } from 'lucide-react'

export default function AdminHeader() {
  const { user } = useAuth()

  return (
    <header className="bg-white border-b border-dark-100 h-16 flex items-center justify-between px-6 sticky top-0 z-40">
      <div>
        <h1 className="text-lg font-semibold text-dark-900">Admin Dashboard</h1>
      </div>
      <div className="flex items-center gap-4">
        <button className="relative p-2 text-dark-400 hover:text-dark-600 transition-colors">
          <Bell className="w-5 h-5" />
          <span className="absolute top-1.5 right-1.5 w-2 h-2 bg-red-500 rounded-full" />
        </button>
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 bg-primary-100 rounded-full flex items-center justify-center">
            <User className="w-5 h-5 text-primary-800" />
          </div>
          <div className="hidden sm:block">
            <p className="text-sm font-medium text-dark-900">{user?.email || 'Admin'}</p>
            <p className="text-xs text-dark-400">Administrator</p>
          </div>
        </div>
      </div>
    </header>
  )
}
