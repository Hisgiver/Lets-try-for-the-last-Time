import { Link, useLocation } from 'react-router-dom'
import {
  LayoutDashboard,
  Package,
  Grid3X3,
  ShoppingBag,
  Image,
  Star,
  Settings,
  HelpCircle,
  LogOut,
} from 'lucide-react'
import { useAuth } from '@/contexts/AuthContext'
import { cn } from '@/lib/utils'

const navItems = [
  { icon: LayoutDashboard, label: 'Dashboard', href: '/admin' },
  { icon: Package, label: 'Products', href: '/admin/products' },
  { icon: Grid3X3, label: 'Categories', href: '/admin/categories' },
  { icon: ShoppingBag, label: 'Orders', href: '/admin/orders' },
  { icon: Image, label: 'Banners', href: '/admin/banners' },
  { icon: Star, label: 'Reviews', href: '/admin/reviews' },
  { icon: HelpCircle, label: 'FAQs', href: '/admin/faqs' },
  { icon: Settings, label: 'Settings', href: '/admin/settings' },
]

export default function AdminSidebar() {
  const location = useLocation()
  const { signOut } = useAuth()

  return (
    <aside className="fixed left-0 top-0 h-full w-64 bg-dark-950 text-white z-50 flex flex-col">
      <div className="p-6 border-b border-dark-800">
        <Link to="/admin" className="flex items-center gap-2">
          <div className="w-10 h-10 bg-primary-800 rounded-lg flex items-center justify-center">
            <span className="text-white font-bold text-lg">CB</span>
          </div>
          <div>
            <span className="text-lg font-bold">China Bazar</span>
            <p className="text-xs text-dark-400">Admin Panel</p>
          </div>
        </Link>
      </div>

      <nav className="flex-1 p-4 space-y-1 overflow-y-auto">
        {navItems.map((item) => {
          const isActive = location.pathname === item.href
          return (
            <Link
              key={item.href}
              to={item.href}
              className={cn(
                'flex items-center gap-3 px-4 py-3 rounded-lg transition-colors text-sm',
                isActive
                  ? 'bg-primary-800 text-white'
                  : 'text-dark-300 hover:bg-dark-800 hover:text-white'
              )}
            >
              <item.icon className="w-5 h-5" />
              {item.label}
            </Link>
          )
        })}
      </nav>

      <div className="p-4 border-t border-dark-800">
        <button
          onClick={signOut}
          className="flex items-center gap-3 px-4 py-3 rounded-lg text-dark-300 hover:bg-dark-800 hover:text-white transition-colors text-sm w-full"
        >
          <LogOut className="w-5 h-5" />
          Sign Out
        </button>
      </div>
    </aside>
  )
}
