import { Link } from 'react-router-dom'
import { ShoppingCart, Eye } from 'lucide-react'
import { useCartStore } from '@/contexts/CartContext'
import { formatPrice, calculateDiscountPercentage } from '@/lib/utils'
import type { Product } from '@/types'
import toast from 'react-hot-toast'

interface ProductCardProps {
  product: Product
}

export default function ProductCard({ product }: ProductCardProps) {
  const addItem = useCartStore((state) => state.addItem)
  const hasDiscount = product.discount_price && product.discount_price < product.price
  const discountPercent = hasDiscount
    ? calculateDiscountPercentage(product.price, product.discount_price!)
    : 0

  const handleAddToCart = (e: React.MouseEvent) => {
    e.preventDefault()
    e.stopPropagation()
    if (!product.is_available || product.stock_quantity <= 0) {
      toast.error('Product is out of stock')
      return
    }
    addItem(product, 1)
    toast.success(`${product.name} added to cart`)
  }

  return (
    <div className="group card">
      {/* Image */}
      <Link to={`/product/${product.slug}`} className="relative block aspect-square overflow-hidden bg-dark-50">
        <img
          src={product.images[0] || '/placeholder-product.jpg'}
          alt={product.name}
          loading="lazy"
          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
        />
        {hasDiscount && (
          <span className="absolute top-3 left-3 bg-red-500 text-white text-xs font-bold px-2.5 py-1 rounded-full">
            -{discountPercent}%
          </span>
        )}
        {product.is_new_arrival && (
          <span className="absolute top-3 right-3 bg-primary-800 text-white text-xs font-bold px-2.5 py-1 rounded-full">
            New
          </span>
        )}
        {/* Quick Actions */}
        <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-center justify-center gap-3">
          <Link
            to={`/product/${product.slug}`}
            className="w-10 h-10 bg-white rounded-full flex items-center justify-center hover:bg-primary-800 hover:text-white transition-colors"
          >
            <Eye className="w-5 h-5" />
          </Link>
          <button
            onClick={handleAddToCart}
            disabled={!product.is_available || product.stock_quantity <= 0}
            className="w-10 h-10 bg-white rounded-full flex items-center justify-center hover:bg-primary-800 hover:text-white transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
          >
            <ShoppingCart className="w-5 h-5" />
          </button>
        </div>
      </Link>

      {/* Content */}
      <div className="p-4">
        <p className="text-xs text-dark-400 mb-1">{product.brand || 'China Bazar'}</p>
        <Link to={`/product/${product.slug}`}>
          <h3 className="font-medium text-dark-900 hover:text-primary-800 transition-colors line-clamp-2 mb-2 text-sm">
            {product.name}
          </h3>
        </Link>
        <div className="flex items-center gap-2">
          <span className="text-lg font-bold text-primary-800">
            {formatPrice(hasDiscount ? product.discount_price! : product.price)}
          </span>
          {hasDiscount && (
            <span className="text-sm text-dark-400 line-through">
              {formatPrice(product.price)}
            </span>
          )}
        </div>
        {product.stock_quantity <= 5 && product.stock_quantity > 0 && (
          <p className="text-xs text-red-500 mt-1">Only {product.stock_quantity} left</p>
        )}
        {product.stock_quantity <= 0 && (
          <p className="text-xs text-red-500 mt-1 font-medium">Out of Stock</p>
        )}
      </div>
    </div>
  )
}
