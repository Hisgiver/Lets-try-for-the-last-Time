import { Link } from 'react-router-dom'
import { MapPin, Phone, Mail, Facebook, Instagram, Youtube } from 'lucide-react'

export default function Footer() {
  return (
    <footer className="bg-dark-950 text-dark-200">
      {/* Main Footer */}
      <div className="section-padding max-w-7xl mx-auto py-12 lg:py-16">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 lg:gap-12">
          {/* Brand */}
          <div className="space-y-4">
            <div className="flex items-center gap-2">
              <div className="w-10 h-10 bg-primary-800 rounded-lg flex items-center justify-center">
                <span className="text-white font-bold text-lg">CB</span>
              </div>
              <span className="text-xl font-bold text-white">China Bazar</span>
            </div>
            <p className="text-dark-300 text-sm leading-relaxed">
              Your trusted destination for premium Chinese products in Bangladesh. Quality guaranteed, delivered to your doorstep.
            </p>
            <div className="flex items-center gap-3">
              <a href="#" className="w-9 h-9 rounded-full bg-dark-800 flex items-center justify-center hover:bg-primary-800 transition-colors">
                <Facebook className="w-4 h-4" />
              </a>
              <a href="#" className="w-9 h-9 rounded-full bg-dark-800 flex items-center justify-center hover:bg-primary-800 transition-colors">
                <Instagram className="w-4 h-4" />
              </a>
              <a href="#" className="w-9 h-9 rounded-full bg-dark-800 flex items-center justify-center hover:bg-primary-800 transition-colors">
                <Youtube className="w-4 h-4" />
              </a>
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h3 className="text-white font-semibold mb-4">Quick Links</h3>
            <ul className="space-y-2.5">
              <li><Link to="/" className="text-dark-300 hover:text-white transition-colors text-sm">Home</Link></li>
              <li><Link to="/shop" className="text-dark-300 hover:text-white transition-colors text-sm">Shop</Link></li>
              <li><Link to="/faq" className="text-dark-300 hover:text-white transition-colors text-sm">FAQ</Link></li>
              <li><Link to="/contact" className="text-dark-300 hover:text-white transition-colors text-sm">Contact Us</Link></li>
            </ul>
          </div>

          {/* Customer Service */}
          <div>
            <h3 className="text-white font-semibold mb-4">Customer Service</h3>
            <ul className="space-y-2.5">
              <li><Link to="/shipping-policy" className="text-dark-300 hover:text-white transition-colors text-sm">Shipping Policy</Link></li>
              <li><Link to="/return-policy" className="text-dark-300 hover:text-white transition-colors text-sm">Return Policy</Link></li>
              <li><Link to="/privacy-policy" className="text-dark-300 hover:text-white transition-colors text-sm">Privacy Policy</Link></li>
              <li><Link to="/terms-conditions" className="text-dark-300 hover:text-white transition-colors text-sm">Terms & Conditions</Link></li>
            </ul>
          </div>

          {/* Contact Info */}
          <div>
            <h3 className="text-white font-semibold mb-4">Contact Us</h3>
            <ul className="space-y-3">
              <li className="flex items-start gap-3 text-sm">
                <MapPin className="w-5 h-5 text-primary-500 shrink-0 mt-0.5" />
                <span className="text-dark-300">Dhaka, Bangladesh</span>
              </li>
              <li className="flex items-center gap-3 text-sm">
                <Phone className="w-5 h-5 text-primary-500 shrink-0" />
                <span className="text-dark-300">+880 1XXX-XXXXXX</span>
              </li>
              <li className="flex items-center gap-3 text-sm">
                <Mail className="w-5 h-5 text-primary-500 shrink-0" />
                <span className="text-dark-300">support@chinabazar.com</span>
              </li>
            </ul>
          </div>
        </div>
      </div>

      {/* Bottom Bar */}
      <div className="border-t border-dark-800">
        <div className="section-padding max-w-7xl mx-auto py-4 flex flex-col sm:flex-row justify-between items-center gap-2">
          <p className="text-dark-400 text-sm">
            © {new Date().getFullYear()} China Bazar. All rights reserved.
          </p>
          <p className="text-dark-500 text-xs">
            Cash on Delivery Available | Quality Guaranteed
          </p>
        </div>
      </div>
    </footer>
  )
}
