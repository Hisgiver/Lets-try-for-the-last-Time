interface SectionHeaderProps {
  title: string
  subtitle?: string
  action?: { label: string; href: string }
}

export default function SectionHeader({ title, subtitle, action }: SectionHeaderProps) {
  return (
    <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4 mb-8">
      <div>
        <h2 className="text-2xl lg:text-3xl font-bold text-dark-900">{title}</h2>
        {subtitle && <p className="text-dark-500 mt-1">{subtitle}</p>}
      </div>
      {action && (
        <a
          href={action.href}
          className="text-primary-800 font-medium hover:text-primary-900 transition-colors text-sm"
        >
          {action.label} →
        </a>
      )}
    </div>
  )
}
