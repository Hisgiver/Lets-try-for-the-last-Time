import { useState } from 'react'
import { Link, useNavigate } from 'react-router-dom'
import { Search, ShoppingCart, Menu, X, Phone, User } from 'lucide-react'
import { useCartStore } from '@/contexts/CartContext'
import { useQuery } from '@tanstack/react-query'
import { supabase } from '@/lib/supabase'
import { cn } from '@/lib/utils'

export default function Navbar() {
  const [isMenuOpen, setIsMenuOpen] = useState(false)
  const [searchQuery, setSearchQuery] = useState('')
  const navigate = useNavigate()
  const totalItems = useCartStore((state) => state.getTotalItems())

  const { data: categories } = useQuery({
    queryKey: ['categories'],
    queryFn: async () => {
      const { data } = await supabase
        .from('categories')
        .select('*')
        .eq('is_active', true)
        .order('sort_order')
      return data || []
    },
  })

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault()
    if (searchQuery.trim()) {
      navigate(`/shop?search=${encodeURIComponent(searchQuery.trim())}`)
      setSearchQuery('')
    }
  }

  return (
    <header className="sticky top-0 z-50 bg-white shadow-sm">
      {/* Top Bar */}
      <div className="bg-primary-900 text-white text-sm py-2">
        <div className="section-padding max-w-7xl mx-auto flex justify-between items-center">
          <div className="flex items-center gap-4">
            <span className="flex items-center gap-1">
              <Phone className="w-3.5 h-3.5" />
              +880 1XXX-XXXXXX
            </span>
          </div>
          <span className="hidden sm:block">Free shipping on orders over ৳1,000</span>
        </div>
      </div>

      {/* Main Navbar */}
      <div className="section-padding max-w-7xl mx-auto">
        <div className="flex items-center justify-between h-16 lg:h-20">
          {/* Logo */}
          <Link to="/" className="flex items-center gap-2">
            <div className="w-10 h-10 bg-primary-800 rounded-lg flex items-center justify-center">
              <span className="text-white font-bold text-lg">CB</span>
            </div>
            <span className="text-xl font-bold text-primary-900 hidden sm:block">China Bazar</span>
          </Link>

          {/* Search Bar - Desktop */}
          <form onSubmit={handleSearch} className="hidden md:flex flex-1 max-w-xl mx-8">
            <div className="relative w-full">
              <input
                type="text"
                placeholder="Search products..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full pl-4 pr-12 py-2.5 border border-dark-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-primary-500 focus:border-transparent"
              />
              <button
                type="submit"
                className="absolute right-2 top-1/2 -translate-y-1/2 p-1.5 text-dark-400 hover:text-primary-800"
              >
                <Search className="w-5 h-5" />
              </button>
            </div>
          </form>

          {/* Right Actions */}
          <div className="flex items-center gap-3">
            <Link
              to="/cart"
              className="relative p-2 text-dark-700 hover:text-primary-800 transition-colors"
            >
              <ShoppingCart className="w-6 h-6" />
              {totalItems > 0 && (
                <span className="absolute -top-1 -right-1 bg-primary-800 text-white text-xs font-bold w-5 h-5 rounded-full flex items-center justify-center">
                  {totalItems}
                </span>
              )}
            </Link>
            <button
              onClick={() => setIsMenuOpen(!isMenuOpen)}
              className="lg:hidden p-2 text-dark-700"
            >
              {isMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </div>
      </div>

      {/* Navigation Links - Desktop */}
      <nav className="hidden lg:block border-t border-dark-100">
        <div className="section-padding max-w-7xl mx-auto">
          <div className="flex items-center gap-8 h-12">
            <Link to="/" className="text-sm font-medium text-dark-700 hover:text-primary-800 transition-colors">
              Home
            </Link>
            <Link to="/shop" className="text-sm font-medium text-dark-700 hover:text-primary-800 transition-colors">
              Shop
            </Link>
            {categories?.map((cat) => (
              <Link
                key={cat.id}
                to={`/shop?category=${cat.slug}`}
                className="text-sm font-medium text-dark-700 hover:text-primary-800 transition-colors"
              >
                {cat.name}
              </Link>
            ))}
            <Link to="/contact" className="text-sm font-medium text-dark-700 hover:text-primary-800 transition-colors">
              Contact
            </Link>
          </div>
        </div>
      </nav>

      {/* Mobile Menu */}
      <div
        className={cn(
          'lg:hidden fixed inset-0 top-[120px] bg-white z-40 transform transition-transform duration-300',
          isMenuOpen ? 'translate-x-0' : 'translate-x-full'
        )}
      >
        <div className="p-4 space-y-4">
          <form onSubmit={handleSearch} className="mb-4">
            <div className="relative">
              <input
                type="text"
                placeholder="Search products..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full pl-4 pr-12 py-3 border border-dark-200 rounded-lg"
              />
              <button type="submit" className="absolute right-3 top-1/2 -translate-y-1/2">
                <Search className="w-5 h-5 text-dark-400" />
              </button>
            </div>
          </form>
          <Link to="/" onClick={() => setIsMenuOpen(false)} className="block py-3 text-lg font-medium border-b border-dark-100">
            Home
          </Link>
          <Link to="/shop" onClick={() => setIsMenuOpen(false)} className="block py-3 text-lg font-medium border-b border-dark-100">
            Shop
          </Link>
          {categories?.map((cat) => (
            <Link
              key={cat.id}
              to={`/shop?category=${cat.slug}`}
              onClick={() => setIsMenuOpen(false)}
              className="block py-3 text-lg font-medium border-b border-dark-100"
            >
              {cat.name}
            </Link>
          ))}
          <Link to="/contact" onClick={() => setIsMenuOpen(false)} className="block py-3 text-lg font-medium border-b border-dark-100">
            Contact
          </Link>
          <Link to="/cart" onClick={() => setIsMenuOpen(false)} className="block py-3 text-lg font-medium border-b border-dark-100">
            Cart ({totalItems})
          </Link>
        </div>
      </div>
    </header>
  )
}
