import { Helmet } from 'react-helmet-async'

export default function ShippingPolicyPage() {
  return (
    <>
      <Helmet>
        <title>Shipping Policy - China Bazar</title>
      </Helmet>
      <div className="section-padding max-w-4xl mx-auto py-12">
        <h1 className="text-3xl font-bold text-dark-900 mb-6">Shipping Policy</h1>
        <div className="prose prose-dark max-w-none">
          <p className="text-dark-600 mb-4">Last updated: {new Date().toLocaleDateString()}</p>
          <p className="text-dark-600 mb-4">China Bazar offers reliable shipping across Bangladesh. We partner with trusted courier services to ensure your orders arrive safely and on time.</p>
          <h2 className="text-xl font-bold text-dark-900 mt-8 mb-4">Shipping Rates</h2>
          <p className="text-dark-600 mb-4">Standard shipping fee is ৳60 per order. Free shipping is available on all orders over ৳1,000.</p>
          <h2 className="text-xl font-bold text-dark-900 mt-8 mb-4">Delivery Time</h2>
          <p className="text-dark-600 mb-4">Delivery within Dhaka typically takes 1-3 business days. Delivery to other districts may take 3-7 business days depending on location.</p>
          <h2 className="text-xl font-bold text-dark-900 mt-8 mb-4">Order Tracking</h2>
          <p className="text-dark-600 mb-4">Once your order is shipped, you will receive a confirmation message with tracking details. You can also contact our support team for order status updates.</p>
        </div>
      </div>
    </>
  )
}
