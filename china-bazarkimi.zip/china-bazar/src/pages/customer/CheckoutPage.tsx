import { useState } from 'react'
import { Helmet } from 'react-helmet-async'
import { useNavigate } from 'react-router-dom'
import { useMutation } from '@tanstack/react-query'
import { supabase } from '@/lib/supabase'
import { useCartStore } from '@/contexts/CartContext'
import { formatPrice, generateOrderNumber } from '@/lib/utils'
import { CreditCard, MapPin, Phone, Mail, User, FileText, ChevronRight } from 'lucide-react'
import toast from 'react-hot-toast'

export default function CheckoutPage() {
  const navigate = useNavigate()
  const { items, getTotalPrice, clearCart } = useCartStore()
  const [isSubmitting, setIsSubmitting] = useState(false)

  const [formData, setFormData] = useState({
    customer_name: '',
    customer_phone: '',
    customer_email: '',
    customer_address: '',
    district: '',
    area_upazila: '',
    order_notes: '',
  })

  const [errors, setErrors] = useState<Record<string, string>>({})

  const shippingCost = getTotalPrice() >= 1000 ? 0 : 60
  const total = getTotalPrice() + shippingCost

  const validateForm = () => {
    const newErrors: Record<string, string> = {}
    if (!formData.customer_name.trim()) newErrors.customer_name = 'Full name is required'
    if (!formData.customer_phone.trim()) newErrors.customer_phone = 'Phone number is required'
    if (!formData.customer_email.trim()) newErrors.customer_email = 'Email is required'
    else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.customer_email)) {
      newErrors.customer_email = 'Invalid email address'
    }
    if (!formData.customer_address.trim()) newErrors.customer_address = 'Delivery address is required'
    if (!formData.district.trim()) newErrors.district = 'District is required'
    if (!formData.area_upazila.trim()) newErrors.area_upazila = 'Area/Upazila is required'
    setErrors(newErrors)
    return Object.keys(newErrors).length === 0
  }

  const placeOrder = useMutation({
    mutationFn: async () => {
      const orderNumber = generateOrderNumber()

      // Create order
      const { data: order, error: orderError } = await supabase
        .from('orders')
        .insert({
          order_number: orderNumber,
          customer_name: formData.customer_name,
          customer_phone: formData.customer_phone,
          customer_email: formData.customer_email,
          customer_address: formData.customer_address,
          district: formData.district,
          area_upazila: formData.area_upazila,
          order_notes: formData.order_notes || null,
          subtotal: getTotalPrice(),
          shipping_cost: shippingCost,
          total_amount: total,
          status: 'pending',
          payment_method: 'cod',
          payment_status: 'pending',
        })
        .select()
        .single()

      if (orderError) throw orderError

      // Create order items
      const orderItems = items.map((item) => ({
        order_id: order.id,
        product_id: item.product.id,
        product_name: item.product.name,
        product_image: item.product.images[0] || null,
        quantity: item.quantity,
        unit_price: item.product.discount_price || item.product.price,
        total_price: (item.product.discount_price || item.product.price) * item.quantity,
      }))

      const { error: itemsError } = await supabase.from('order_items').insert(orderItems)
      if (itemsError) throw itemsError

      // Update stock quantities
      for (const item of items) {
        await supabase.rpc('decrement_stock', {
          product_id: item.product.id,
          quantity: item.quantity,
        })
      }

      return order
    },
    onSuccess: (order) => {
      clearCart()
      toast.success('Order placed successfully!')
      navigate(`/order-success/${order.id}`)
    },
    onError: (error) => {
      console.error('Order error:', error)
      toast.error('Failed to place order. Please try again.')
      setIsSubmitting(false)
    },
  })

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    if (!validateForm()) return
    if (items.length === 0) {
      toast.error('Your cart is empty')
      return
    }
    setIsSubmitting(true)
    placeOrder.mutate()
  }

  if (items.length === 0) {
    return (
      <div className="min-h-[60vh] flex items-center justify-center">
        <div className="text-center">
          <h1 className="text-2xl font-bold text-dark-900 mb-2">Your Cart is Empty</h1>
          <p className="text-dark-500 mb-6">Add some products to proceed with checkout.</p>
        </div>
      </div>
    )
  }

  return (
    <>
      <Helmet>
        <title>Checkout - China Bazar</title>
      </Helmet>

      <div className="section-padding max-w-7xl mx-auto py-8">
        <h1 className="text-2xl lg:text-3xl font-bold text-dark-900 mb-2">Checkout</h1>
        <p className="text-dark-500 mb-8">Complete your order by filling in your details below</p>

        <div className="flex flex-col lg:flex-row gap-8">
          {/* Checkout Form */}
          <div className="flex-1">
            <form onSubmit={handleSubmit} className="space-y-6">
              {/* Contact Information */}
              <div className="bg-white p-6 rounded-xl border border-dark-100">
                <h2 className="text-lg font-bold text-dark-900 mb-4 flex items-center gap-2">
                  <User className="w-5 h-5 text-primary-800" />
                  Contact Information
                </h2>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div className="sm:col-span-2">
                    <label className="block text-sm font-medium text-dark-700 mb-1">
                      Full Name *
                    </label>
                    <input
                      type="text"
                      value={formData.customer_name}
                      onChange={(e) => setFormData({ ...formData, customer_name: e.target.value })}
                      className={`input-field ${errors.customer_name ? 'border-red-500' : ''}`}
                      placeholder="Enter your full name"
                    />
                    {errors.customer_name && (
                      <p className="text-red-500 text-xs mt-1">{errors.customer_name}</p>
                    )}
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-dark-700 mb-1">
                      Phone Number *
                    </label>
                    <div className="relative">
                      <Phone className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-dark-400" />
                      <input
                        type="tel"
                        value={formData.customer_phone}
                        onChange={(e) => setFormData({ ...formData, customer_phone: e.target.value })}
                        className={`input-field pl-10 ${errors.customer_phone ? 'border-red-500' : ''}`}
                        placeholder="01XXXXXXXXX"
                      />
                    </div>
                    {errors.customer_phone && (
                      <p className="text-red-500 text-xs mt-1">{errors.customer_phone}</p>
                    )}
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-dark-700 mb-1">
                      Email *
                    </label>
                    <div className="relative">
                      <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-dark-400" />
                      <input
                        type="email"
                        value={formData.customer_email}
                        onChange={(e) => setFormData({ ...formData, customer_email: e.target.value })}
                        className={`input-field pl-10 ${errors.customer_email ? 'border-red-500' : ''}`}
                        placeholder="your@email.com"
                      />
                    </div>
                    {errors.customer_email && (
                      <p className="text-red-500 text-xs mt-1">{errors.customer_email}</p>
                    )}
                  </div>
                </div>
              </div>

              {/* Shipping Address */}
              <div className="bg-white p-6 rounded-xl border border-dark-100">
                <h2 className="text-lg font-bold text-dark-900 mb-4 flex items-center gap-2">
                  <MapPin className="w-5 h-5 text-primary-800" />
                  Shipping Address
                </h2>
                <div className="space-y-4">
                  <div>
                    <label className="block text-sm font-medium text-dark-700 mb-1">
                      Full Delivery Address *
                    </label>
                    <textarea
                      rows={3}
                      value={formData.customer_address}
                      onChange={(e) => setFormData({ ...formData, customer_address: e.target.value })}
                      className={`input-field ${errors.customer_address ? 'border-red-500' : ''}`}
                      placeholder="House/Building, Road, Area, Thana"
                    />
                    {errors.customer_address && (
                      <p className="text-red-500 text-xs mt-1">{errors.customer_address}</p>
                    )}
                  </div>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-sm font-medium text-dark-700 mb-1">
                        District *
                      </label>
                      <input
                        type="text"
                        value={formData.district}
                        onChange={(e) => setFormData({ ...formData, district: e.target.value })}
                        className={`input-field ${errors.district ? 'border-red-500' : ''}`}
                        placeholder="e.g. Dhaka"
                      />
                      {errors.district && (
                        <p className="text-red-500 text-xs mt-1">{errors.district}</p>
                      )}
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-dark-700 mb-1">
                        Area/Upazila *
                      </label>
                      <input
                        type="text"
                        value={formData.area_upazila}
                        onChange={(e) => setFormData({ ...formData, area_upazila: e.target.value })}
                        className={`input-field ${errors.area_upazila ? 'border-red-500' : ''}`}
                        placeholder="e.g. Mirpur"
                      />
                      {errors.area_upazila && (
                        <p className="text-red-500 text-xs mt-1">{errors.area_upazila}</p>
                      )}
                    </div>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-dark-700 mb-1">
                      Order Notes (Optional)
                    </label>
                    <div className="relative">
                      <FileText className="absolute left-3 top-3 w-5 h-5 text-dark-400" />
                      <textarea
                        rows={3}
                        value={formData.order_notes}
                        onChange={(e) => setFormData({ ...formData, order_notes: e.target.value })}
                        className="input-field pl-10"
                        placeholder="Any special instructions for delivery"
                      />
                    </div>
                  </div>
                </div>
              </div>

              {/* Payment Method */}
              <div className="bg-white p-6 rounded-xl border border-dark-100">
                <h2 className="text-lg font-bold text-dark-900 mb-4 flex items-center gap-2">
                  <CreditCard className="w-5 h-5 text-primary-800" />
                  Payment Method
                </h2>
                <div className="border-2 border-primary-800 bg-primary-50 rounded-lg p-4">
                  <div className="flex items-center gap-3">
                    <div className="w-5 h-5 rounded-full border-4 border-primary-800 bg-white" />
                    <div>
                      <p className="font-medium text-dark-900">Cash on Delivery (COD)</p>
                      <p className="text-sm text-dark-500">Pay when you receive your order</p>
                    </div>
                  </div>
                </div>
                <p className="text-xs text-dark-400 mt-3">
                  Online payment options will be available soon.
                </p>
              </div>

              <button
                type="submit"
                disabled={isSubmitting}
                className="btn-primary w-full py-4 text-lg gap-2"
              >
                {isSubmitting ? 'Placing Order...' : `Place Order - ${formatPrice(total)}`}
                <ChevronRight className="w-5 h-5" />
              </button>
            </form>
          </div>

          {/* Order Summary */}
          <div className="lg:w-96 shrink-0">
            <div className="bg-white p-6 rounded-xl border border-dark-100 sticky top-24">
              <h2 className="text-lg font-bold text-dark-900 mb-4">Order Summary</h2>
              <div className="space-y-3 max-h-64 overflow-y-auto">
                {items.map((item) => (
                  <div key={item.product.id} className="flex gap-3">
                    <img
                      src={item.product.images[0] || '/placeholder-product.jpg'}
                      alt={item.product.name}
                      className="w-16 h-16 object-cover rounded-lg"
                    />
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-medium text-dark-900 truncate">{item.product.name}</p>
                      <p className="text-xs text-dark-400">Qty: {item.quantity}</p>
                      <p className="text-sm font-medium text-primary-800">
                        {formatPrice((item.product.discount_price || item.product.price) * item.quantity)}
                      </p>
                    </div>
                  </div>
                ))}
              </div>
              <div className="border-t border-dark-100 mt-4 pt-4 space-y-2 text-sm">
                <div className="flex justify-between text-dark-600">
                  <span>Subtotal</span>
                  <span>{formatPrice(getTotalPrice())}</span>
                </div>
                <div className="flex justify-between text-dark-600">
                  <span>Shipping</span>
                  <span>{shippingCost === 0 ? 'Free' : formatPrice(shippingCost)}</span>
                </div>
                <div className="border-t border-dark-100 pt-2">
                  <div className="flex justify-between font-bold text-lg text-dark-900">
                    <span>Total</span>
                    <span>{formatPrice(total)}</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  )
}
