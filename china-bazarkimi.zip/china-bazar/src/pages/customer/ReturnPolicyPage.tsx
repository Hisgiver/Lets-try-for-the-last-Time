import { Helmet } from 'react-helmet-async'

export default function ReturnPolicyPage() {
  return (
    <>
      <Helmet>
        <title>Return Policy - China Bazar</title>
      </Helmet>
      <div className="section-padding max-w-4xl mx-auto py-12">
        <h1 className="text-3xl font-bold text-dark-900 mb-6">Return Policy</h1>
        <div className="prose prose-dark max-w-none">
          <p className="text-dark-600 mb-4">Last updated: {new Date().toLocaleDateString()}</p>
          <p className="text-dark-600 mb-4">At China Bazar, we want you to be completely satisfied with your purchase. If you are not satisfied, we offer a hassle-free return policy.</p>
          <h2 className="text-xl font-bold text-dark-900 mt-8 mb-4">Return Period</h2>
          <p className="text-dark-600 mb-4">You may return most items within 7 days of delivery for a full refund or exchange. Items must be unused and in their original packaging.</p>
          <h2 className="text-xl font-bold text-dark-900 mt-8 mb-4">Return Process</h2>
          <p className="text-dark-600 mb-4">To initiate a return, please contact our customer support team with your order number and reason for return. We will arrange for pickup or provide return instructions.</p>
          <h2 className="text-xl font-bold text-dark-900 mt-8 mb-4">Non-Returnable Items</h2>
          <p className="text-dark-600 mb-4">Certain items cannot be returned, including perishable goods, intimate apparel, and items marked as non-returnable.</p>
        </div>
      </div>
    </>
  )
}
