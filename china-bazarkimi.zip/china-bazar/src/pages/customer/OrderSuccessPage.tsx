import { Helmet } from 'react-helmet-async'
import { Link, useParams } from 'react-router-dom'
import { useQuery } from '@tanstack/react-query'
import { supabase } from '@/lib/supabase'
import { CheckCircle, Package, Phone, Mail, MapPin, Calendar } from 'lucide-react'
import { formatPrice, orderStatusLabels, orderStatusColors } from '@/lib/utils'

export default function OrderSuccessPage() {
  const { orderId } = useParams<{ orderId: string }>()

  const { data: order } = useQuery({
    queryKey: ['order', orderId],
    queryFn: async () => {
      const { data } = await supabase
        .from('orders')
        .select('*, order_items(*)')
        .eq('id', orderId)
        .single()
      return data
    },
  })

  if (!order) {
    return (
      <div className="min-h-[60vh] flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary-800"></div>
      </div>
    )
  }

  return (
    <>
      <Helmet>
        <title>Order Confirmed - China Bazar</title>
      </Helmet>

      <div className="section-padding max-w-3xl mx-auto py-12">
        <div className="text-center mb-8">
          <div className="w-20 h-20 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
            <CheckCircle className="w-10 h-10 text-green-600" />
          </div>
          <h1 className="text-2xl lg:text-3xl font-bold text-dark-900 mb-2">Order Confirmed!</h1>
          <p className="text-dark-500">
            Thank you for your order. We will contact you shortly to confirm the delivery details.
          </p>
        </div>

        <div className="bg-white rounded-xl border border-dark-100 overflow-hidden">
          {/* Order Header */}
          <div className="bg-primary-900 text-white p-6">
            <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
              <div>
                <p className="text-primary-200 text-sm">Order Number</p>
                <p className="text-xl font-bold">{order.order_number}</p>
              </div>
              <span className={`px-3 py-1 rounded-full text-sm font-medium ${orderStatusColors[order.status as keyof typeof orderStatusColors] || 'bg-gray-100 text-gray-800'}`}>
                {orderStatusLabels[order.status as keyof typeof orderStatusLabels] || order.status}
              </span>
            </div>
          </div>

          {/* Order Details */}
          <div className="p-6 space-y-6">
            {/* Customer Info */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="flex items-start gap-3">
                <Package className="w-5 h-5 text-primary-800 mt-0.5" />
                <div>
                  <p className="text-sm text-dark-500">Customer</p>
                  <p className="font-medium text-dark-900">{order.customer_name}</p>
                </div>
              </div>
              <div className="flex items-start gap-3">
                <Phone className="w-5 h-5 text-primary-800 mt-0.5" />
                <div>
                  <p className="text-sm text-dark-500">Phone</p>
                  <p className="font-medium text-dark-900">{order.customer_phone}</p>
                </div>
              </div>
              <div className="flex items-start gap-3">
                <Mail className="w-5 h-5 text-primary-800 mt-0.5" />
                <div>
                  <p className="text-sm text-dark-500">Email</p>
                  <p className="font-medium text-dark-900">{order.customer_email}</p>
                </div>
              </div>
              <div className="flex items-start gap-3">
                <Calendar className="w-5 h-5 text-primary-800 mt-0.5" />
                <div>
                  <p className="text-sm text-dark-500">Order Date</p>
                  <p className="font-medium text-dark-900">
                    {new Date(order.created_at).toLocaleDateString('en-BD', {
                      year: 'numeric',
                      month: 'long',
                      day: 'numeric',
                    })}
                  </p>
                </div>
              </div>
            </div>

            {/* Address */}
            <div className="flex items-start gap-3 p-4 bg-dark-50 rounded-lg">
              <MapPin className="w-5 h-5 text-primary-800 mt-0.5 shrink-0" />
              <div>
                <p className="text-sm text-dark-500">Delivery Address</p>
                <p className="font-medium text-dark-900">{order.customer_address}</p>
                <p className="text-dark-600">{order.area_upazila}, {order.district}</p>
              </div>
            </div>

            {/* Order Items */}
            <div>
              <h3 className="font-semibold text-dark-900 mb-3">Order Items</h3>
              <div className="space-y-3">
                {order.order_items?.map((item: any) => (
                  <div key={item.id} className="flex items-center gap-4 p-3 bg-dark-50 rounded-lg">
                    <img
                      src={item.product_image || '/placeholder-product.jpg'}
                      alt={item.product_name}
                      className="w-16 h-16 object-cover rounded-lg"
                    />
                    <div className="flex-1">
                      <p className="font-medium text-dark-900 text-sm">{item.product_name}</p>
                      <p className="text-xs text-dark-400">Qty: {item.quantity}</p>
                    </div>
                    <p className="font-bold text-primary-800">{formatPrice(item.total_price)}</p>
                  </div>
                ))}
              </div>
            </div>

            {/* Order Total */}
            <div className="border-t border-dark-100 pt-4 space-y-2">
              <div className="flex justify-between text-sm text-dark-600">
                <span>Subtotal</span>
                <span>{formatPrice(order.subtotal)}</span>
              </div>
              <div className="flex justify-between text-sm text-dark-600">
                <span>Shipping</span>
                <span>{order.shipping_cost === 0 ? 'Free' : formatPrice(order.shipping_cost)}</span>
              </div>
              <div className="flex justify-between font-bold text-lg text-dark-900 pt-2 border-t border-dark-100">
                <span>Total</span>
                <span>{formatPrice(order.total_amount)}</span>
              </div>
            </div>

            {order.order_notes && (
              <div className="p-4 bg-yellow-50 border border-yellow-100 rounded-lg">
                <p className="text-sm font-medium text-yellow-800 mb-1">Order Notes</p>
                <p className="text-sm text-yellow-700">{order.order_notes}</p>
              </div>
            )}
          </div>
        </div>

        <div className="flex flex-col sm:flex-row gap-4 mt-8 justify-center">
          <Link to="/shop" className="btn-primary text-center">
            Continue Shopping
          </Link>
          <Link to="/" className="btn-secondary text-center">
            Back to Home
          </Link>
        </div>
      </div>
    </>
  )
}
