import { useState } from 'react'
import { Helmet } from 'react-helmet-async'
import { MapPin, Phone, Mail, Clock, Send } from 'lucide-react'
import toast from 'react-hot-toast'

export default function ContactPage() {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    message: '',
  })

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    toast.success('Message sent successfully! We will get back to you soon.')
    setFormData({ name: '', email: '', phone: '', message: '' })
  }

  return (
    <>
      <Helmet>
        <title>Contact Us - China Bazar</title>
        <meta name="description" content="Get in touch with China Bazar. We are here to help you with any questions or concerns." />
      </Helmet>

      <div className="bg-dark-50 py-8">
        <div className="section-padding max-w-7xl mx-auto">
          <h1 className="text-3xl font-bold text-dark-900">Contact Us</h1>
          <p className="text-dark-500 mt-1">We would love to hear from you</p>
        </div>
      </div>

      <div className="section-padding max-w-7xl mx-auto py-12">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Contact Info */}
          <div className="lg:col-span-1 space-y-6">
            <div className="bg-white p-6 rounded-xl border border-dark-100">
              <div className="w-12 h-12 bg-primary-50 rounded-xl flex items-center justify-center mb-4">
                <MapPin className="w-6 h-6 text-primary-800" />
              </div>
              <h3 className="font-semibold text-dark-900 mb-1">Our Address</h3>
              <p className="text-dark-500 text-sm">Dhaka, Bangladesh</p>
            </div>
            <div className="bg-white p-6 rounded-xl border border-dark-100">
              <div className="w-12 h-12 bg-primary-50 rounded-xl flex items-center justify-center mb-4">
                <Phone className="w-6 h-6 text-primary-800" />
              </div>
              <h3 className="font-semibold text-dark-900 mb-1">Phone</h3>
              <p className="text-dark-500 text-sm">+880 1XXX-XXXXXX</p>
            </div>
            <div className="bg-white p-6 rounded-xl border border-dark-100">
              <div className="w-12 h-12 bg-primary-50 rounded-xl flex items-center justify-center mb-4">
                <Mail className="w-6 h-6 text-primary-800" />
              </div>
              <h3 className="font-semibold text-dark-900 mb-1">Email</h3>
              <p className="text-dark-500 text-sm">support@chinabazar.com</p>
            </div>
            <div className="bg-white p-6 rounded-xl border border-dark-100">
              <div className="w-12 h-12 bg-primary-50 rounded-xl flex items-center justify-center mb-4">
                <Clock className="w-6 h-6 text-primary-800" />
              </div>
              <h3 className="font-semibold text-dark-900 mb-1">Working Hours</h3>
              <p className="text-dark-500 text-sm">Sat - Thu: 9:00 AM - 9:00 PM</p>
              <p className="text-dark-500 text-sm">Friday: Closed</p>
            </div>
          </div>

          {/* Contact Form */}
          <div className="lg:col-span-2">
            <div className="bg-white p-8 rounded-xl border border-dark-100">
              <h2 className="text-xl font-bold text-dark-900 mb-6">Send us a Message</h2>
              <form onSubmit={handleSubmit} className="space-y-4">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-dark-700 mb-1">Name *</label>
                    <input
                      type="text"
                      required
                      value={formData.name}
                      onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                      className="input-field"
                      placeholder="Your name"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-dark-700 mb-1">Email *</label>
                    <input
                      type="email"
                      required
                      value={formData.email}
                      onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                      className="input-field"
                      placeholder="your@email.com"
                    />
                  </div>
                </div>
                <div>
                  <label className="block text-sm font-medium text-dark-700 mb-1">Phone</label>
                  <input
                    type="tel"
                    value={formData.phone}
                    onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                    className="input-field"
                    placeholder="01XXXXXXXXX"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-dark-700 mb-1">Message *</label>
                  <textarea
                    required
                    rows={5}
                    value={formData.message}
                    onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                    className="input-field"
                    placeholder="How can we help you?"
                  />
                </div>
                <button type="submit" className="btn-primary gap-2">
                  <Send className="w-4 h-4" />
                  Send Message
                </button>
              </form>
            </div>
          </div>
        </div>
      </div>
    </>
  )
}
