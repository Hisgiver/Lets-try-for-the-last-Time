import { useState } from 'react'
import { Helmet } from 'react-helmet-async'
import { useQuery } from '@tanstack/react-query'
import { supabase } from '@/lib/supabase'
import { ChevronDown, ChevronUp, HelpCircle } from 'lucide-react'

export default function FAQPage() {
  const [openIndex, setOpenIndex] = useState<number | null>(0)

  const { data: faqs } = useQuery({
    queryKey: ['faqs'],
    queryFn: async () => {
      const { data } = await supabase
        .from('faqs')
        .select('*')
        .eq('is_active', true)
        .order('sort_order')
      return data || []
    },
  })

  return (
    <>
      <Helmet>
        <title>FAQ - China Bazar</title>
        <meta name="description" content="Frequently asked questions about China Bazar. Find answers about shipping, returns, payments and more." />
      </Helmet>

      <div className="bg-dark-50 py-8">
        <div className="section-padding max-w-7xl mx-auto">
          <h1 className="text-3xl font-bold text-dark-900">Frequently Asked Questions</h1>
          <p className="text-dark-500 mt-1">Find answers to common questions</p>
        </div>
      </div>

      <div className="section-padding max-w-3xl mx-auto py-12">
        {faqs && faqs.length > 0 ? (
          <div className="space-y-4">
            {faqs.map((faq, index) => (
              <div
                key={faq.id}
                className="bg-white rounded-xl border border-dark-100 overflow-hidden"
              >
                <button
                  onClick={() => setOpenIndex(openIndex === index ? null : index)}
                  className="w-full flex items-center justify-between p-6 text-left"
                >
                  <div className="flex items-center gap-3">
                    <HelpCircle className="w-5 h-5 text-primary-800 shrink-0" />
                    <span className="font-medium text-dark-900">{faq.question}</span>
                  </div>
                  {openIndex === index ? (
                    <ChevronUp className="w-5 h-5 text-dark-400 shrink-0" />
                  ) : (
                    <ChevronDown className="w-5 h-5 text-dark-400 shrink-0" />
                  )}
                </button>
                {openIndex === index && (
                  <div className="px-6 pb-6 pl-14">
                    <p className="text-dark-600 leading-relaxed">{faq.answer}</p>
                  </div>
                )}
              </div>
            ))}
          </div>
        ) : (
          <div className="text-center py-16">
            <HelpCircle className="w-12 h-12 text-dark-300 mx-auto mb-4" />
            <p className="text-dark-500">No FAQs available at the moment.</p>
          </div>
        )}
      </div>
    </>
  )
}
