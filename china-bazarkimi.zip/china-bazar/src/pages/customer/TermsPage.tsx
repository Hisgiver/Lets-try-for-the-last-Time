import { Helmet } from 'react-helmet-async'

export default function TermsPage() {
  return (
    <>
      <Helmet>
        <title>Terms & Conditions - China Bazar</title>
      </Helmet>
      <div className="section-padding max-w-4xl mx-auto py-12">
        <h1 className="text-3xl font-bold text-dark-900 mb-6">Terms & Conditions</h1>
        <div className="prose prose-dark max-w-none">
          <p className="text-dark-600 mb-4">Last updated: {new Date().toLocaleDateString()}</p>
          <p className="text-dark-600 mb-4">Welcome to China Bazar. By accessing and using our website, you agree to comply with and be bound by the following terms and conditions.</p>
          <h2 className="text-xl font-bold text-dark-900 mt-8 mb-4">Use of Website</h2>
          <p className="text-dark-600 mb-4">You agree to use our website for lawful purposes only. You must not use our website in any way that causes damage to the website or impairs its availability.</p>
          <h2 className="text-xl font-bold text-dark-900 mt-8 mb-4">Product Information</h2>
          <p className="text-dark-600 mb-4">We strive to ensure that all product descriptions and images are accurate. However, actual product colors may vary slightly due to monitor settings.</p>
          <h2 className="text-xl font-bold text-dark-900 mt-8 mb-4">Pricing</h2>
          <p className="text-dark-600 mb-4">All prices are listed in Bangladeshi Taka (BDT) and are subject to change without notice. We reserve the right to modify prices at any time.</p>
        </div>
      </div>
    </>
  )
}
