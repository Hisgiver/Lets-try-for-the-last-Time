import { useState } from 'react'
import { Helmet } from 'react-helmet-async'
import { useParams, Link } from 'react-router-dom'
import { useQuery, useMutation } from '@tanstack/react-query'
import { supabase } from '@/lib/supabase'
import { ShoppingCart, Minus, Plus, Star, Truck, Shield, RotateCcw, Check } from 'lucide-react'
import { useCartStore } from '@/contexts/CartContext'
import { formatPrice, calculateDiscountPercentage } from '@/lib/utils'
import ProductCard from '@/components/customer/ProductCard'
import toast from 'react-hot-toast'
import type { Product } from '@/types'

export default function ProductPage() {
  const { slug } = useParams<{ slug: string }>()
  const [quantity, setQuantity] = useState(1)
  const [selectedImage, setSelectedImage] = useState(0)
  const addItem = useCartStore((state) => state.addItem)

  const { data: product, isLoading } = useQuery({
    queryKey: ['product', slug],
    queryFn: async () => {
      const { data } = await supabase
        .from('products')
        .select('*, category:categories(*), subcategory:subcategories(*)')
        .eq('slug', slug)
        .eq('is_available', true)
        .single()
      return data as Product | null
    },
  })

  // Increment view count
  useMutation({
    mutationFn: async () => {
      if (product) {
        await supabase.rpc('increment_view_count', { product_id: product.id })
      }
    },
  })

  const { data: relatedProducts } = useQuery({
    queryKey: ['related-products', product?.category_id],
    queryFn: async () => {
      if (!product?.category_id) return []
      const { data } = await supabase
        .from('products')
        .select('*, category:categories(*)')
        .eq('category_id', product.category_id)
        .eq('is_available', true)
        .neq('id', product.id)
        .limit(4)
      return data || []
    },
    enabled: !!product,
  })

  const { data: reviews } = useQuery({
    queryKey: ['reviews', product?.id],
    queryFn: async () => {
      if (!product?.id) return []
      const { data } = await supabase
        .from('reviews')
        .select('*')
        .eq('product_id', product.id)
        .eq('is_approved', true)
        .order('created_at', { ascending: false })
      return data || []
    },
    enabled: !!product,
  })

  const [reviewForm, setReviewForm] = useState({
    customer_name: '',
    customer_email: '',
    rating: 5,
    title: '',
    comment: '',
  })

  const submitReview = useMutation({
    mutationFn: async () => {
      if (!product) return
      await supabase.from('reviews').insert({
        product_id: product.id,
        ...reviewForm,
      })
    },
    onSuccess: () => {
      toast.success('Review submitted for approval')
      setReviewForm({ customer_name: '', customer_email: '', rating: 5, title: '', comment: '' })
    },
    onError: () => {
      toast.error('Failed to submit review')
    },
  })

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary-800"></div>
      </div>
    )
  }

  if (!product) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <h1 className="text-2xl font-bold text-dark-900 mb-2">Product Not Found</h1>
          <p className="text-dark-500 mb-4">The product you are looking for does not exist.</p>
          <Link to="/shop" className="btn-primary">Browse Products</Link>
        </div>
      </div>
    )
  }

  const hasDiscount = product.discount_price && product.discount_price < product.price
  const discountPercent = hasDiscount
    ? calculateDiscountPercentage(product.price, product.discount_price!)
    : 0

  const averageRating = reviews?.length
    ? reviews.reduce((sum, r) => sum + r.rating, 0) / reviews.length
    : 0

  const handleAddToCart = () => {
    if (product.stock_quantity <= 0) {
      toast.error('Product is out of stock')
      return
    }
    if (quantity > product.stock_quantity) {
      toast.error(`Only ${product.stock_quantity} items available`)
      return
    }
    addItem(product, quantity)
    toast.success(`${product.name} added to cart`)
  }

  return (
    <>
      <Helmet>
        <title>{product.meta_title || product.name} - China Bazar</title>
        <meta name="description" content={product.meta_description || product.short_description || product.description || ''} />
      </Helmet>

      <div className="section-padding max-w-7xl mx-auto py-8">
        {/* Breadcrumb */}
        <nav className="text-sm text-dark-500 mb-6">
          <Link to="/" className="hover:text-primary-800">Home</Link>
          <span className="mx-2">/</span>
          <Link to="/shop" className="hover:text-primary-800">Shop</Link>
          {product.category && (
            <>
              <span className="mx-2">/</span>
              <Link to={`/shop?category=${product.category.slug}`} className="hover:text-primary-800">
                {product.category.name}
              </Link>
            </>
          )}
          <span className="mx-2">/</span>
          <span className="text-dark-900">{product.name}</span>
        </nav>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 lg:gap-12">
          {/* Images */}
          <div className="space-y-4">
            <div className="aspect-square rounded-2xl bg-dark-50 overflow-hidden">
              <img
                src={product.images[selectedImage] || '/placeholder-product.jpg'}
                alt={product.name}
                className="w-full h-full object-cover"
              />
            </div>
            {product.images.length > 1 && (
              <div className="flex gap-3 overflow-x-auto pb-2">
                {product.images.map((img, idx) => (
                  <button
                    key={idx}
                    onClick={() => setSelectedImage(idx)}
                    className={`w-20 h-20 rounded-lg overflow-hidden border-2 flex-shrink-0 ${
                      selectedImage === idx ? 'border-primary-800' : 'border-transparent'
                    }`}
                  >
                    <img src={img} alt="" className="w-full h-full object-cover" />
                  </button>
                ))}
              </div>
            )}
          </div>

          {/* Product Info */}
          <div className="space-y-6">
            <div>
              <p className="text-sm text-dark-400 mb-1">{product.brand || 'China Bazar'}</p>
              <h1 className="text-2xl lg:text-3xl font-bold text-dark-900">{product.name}</h1>
              <div className="flex items-center gap-3 mt-2">
                <div className="flex items-center gap-1">
                  {[...Array(5)].map((_, i) => (
                    <Star
                      key={i}
                      className={`w-4 h-4 ${
                        i < Math.round(averageRating) ? 'text-yellow-400 fill-yellow-400' : 'text-dark-200'
                      }`}
                    />
                  ))}
                </div>
                <span className="text-sm text-dark-500">
                  {averageRating.toFixed(1)} ({reviews?.length || 0} reviews)
                </span>
              </div>
            </div>

            <div className="flex items-baseline gap-3">
              <span className="text-3xl font-bold text-primary-800">
                {formatPrice(hasDiscount ? product.discount_price! : product.price)}
              </span>
              {hasDiscount && (
                <>
                  <span className="text-xl text-dark-400 line-through">
                    {formatPrice(product.price)}
                  </span>
                  <span className="bg-red-100 text-red-700 text-sm font-bold px-2.5 py-1 rounded-full">
                    -{discountPercent}%
                  </span>
                </>
              )}
            </div>

            <p className="text-dark-600 leading-relaxed">
              {product.short_description || product.description}
            </p>

            {/* Stock Status */}
            <div className="flex items-center gap-2">
              {product.stock_quantity > 0 ? (
                <>
                  <Check className="w-5 h-5 text-green-500" />
                  <span className="text-green-600 font-medium">
                    In Stock ({product.stock_quantity} available)
                  </span>
                </>
              ) : (
                <>
                  <span className="w-2 h-2 bg-red-500 rounded-full" />
                  <span className="text-red-500 font-medium">Out of Stock</span>
                </>
              )}
            </div>

            {/* Quantity & Add to Cart */}
            <div className="flex items-center gap-4">
              <div className="flex items-center border border-dark-200 rounded-lg">
                <button
                  onClick={() => setQuantity(Math.max(1, quantity - 1))}
                  className="p-3 hover:bg-dark-50 transition-colors"
                >
                  <Minus className="w-4 h-4" />
                </button>
                <span className="w-12 text-center font-medium">{quantity}</span>
                <button
                  onClick={() => setQuantity(Math.min(product.stock_quantity, quantity + 1))}
                  className="p-3 hover:bg-dark-50 transition-colors"
                  disabled={quantity >= product.stock_quantity}
                >
                  <Plus className="w-4 h-4" />
                </button>
              </div>
              <button
                onClick={handleAddToCart}
                disabled={product.stock_quantity <= 0}
                className="btn-primary flex-1 gap-2"
              >
                <ShoppingCart className="w-5 h-5" />
                Add to Cart
              </button>
            </div>

            {/* Features */}
            <div className="grid grid-cols-3 gap-4 py-6 border-t border-dark-100">
              {[
                { icon: Truck, label: 'Free Delivery', desc: 'Orders over ৳1,000' },
                { icon: Shield, label: 'Authentic', desc: '100% Genuine' },
                { icon: RotateCcw, label: '7-Day Return', desc: 'Easy Returns' },
              ].map((item) => (
                <div key={item.label} className="text-center">
                  <item.icon className="w-6 h-6 text-primary-800 mx-auto mb-2" />
                  <p className="text-sm font-medium text-dark-900">{item.label}</p>
                  <p className="text-xs text-dark-400">{item.desc}</p>
                </div>
              ))}
            </div>

            {/* Specifications */}
            {Object.keys(product.specifications).length > 0 && (
              <div className="border-t border-dark-100 pt-6">
                <h3 className="font-semibold text-dark-900 mb-3">Specifications</h3>
                <dl className="space-y-2">
                  {Object.entries(product.specifications).map(([key, value]) => (
                    <div key={key} className="flex justify-between py-2 border-b border-dark-50">
                      <dt className="text-sm text-dark-500">{key}</dt>
                      <dd className="text-sm font-medium text-dark-900">{value}</dd>
                    </div>
                  ))}
                </dl>
              </div>
            )}
          </div>
        </div>

        {/* Reviews Section */}
        <div className="mt-16">
          <h2 className="text-2xl font-bold text-dark-900 mb-6">Customer Reviews</h2>
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            {/* Review List */}
            <div className="lg:col-span-2 space-y-4">
              {reviews && reviews.length > 0 ? (
                reviews.map((review) => (
                  <div key={review.id} className="bg-white p-6 rounded-xl border border-dark-100">
                    <div className="flex items-center justify-between mb-3">
                      <div className="flex items-center gap-2">
                        <div className="w-10 h-10 bg-primary-100 rounded-full flex items-center justify-center">
                          <span className="text-primary-800 font-bold text-sm">
                            {review.customer_name.charAt(0).toUpperCase()}
                          </span>
                        </div>
                        <div>
                          <p className="font-medium text-dark-900 text-sm">{review.customer_name}</p>
                          <p className="text-xs text-dark-400">
                            {new Date(review.created_at).toLocaleDateString()}
                          </p>
                        </div>
                      </div>
                      <div className="flex items-center gap-0.5">
                        {[...Array(5)].map((_, i) => (
                          <Star
                            key={i}
                            className={`w-4 h-4 ${
                              i < review.rating ? 'text-yellow-400 fill-yellow-400' : 'text-dark-200'
                            }`}
                          />
                        ))}
                      </div>
                    </div>
                    {review.title && (
                      <h4 className="font-medium text-dark-900 mb-1">{review.title}</h4>
                    )}
                    <p className="text-dark-600 text-sm">{review.comment}</p>
                  </div>
                ))
              ) : (
                <p className="text-dark-500">No reviews yet. Be the first to review!</p>
              )}
            </div>

            {/* Review Form */}
            <div className="bg-white p-6 rounded-xl border border-dark-100 h-fit">
              <h3 className="font-semibold text-dark-900 mb-4">Write a Review</h3>
              <form
                onSubmit={(e) => {
                  e.preventDefault()
                  submitReview.mutate()
                }}
                className="space-y-4"
              >
                <div>
                  <label className="block text-sm font-medium text-dark-700 mb-1">Name *</label>
                  <input
                    type="text"
                    required
                    value={reviewForm.customer_name}
                    onChange={(e) => setReviewForm({ ...reviewForm, customer_name: e.target.value })}
                    className="input-field"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-dark-700 mb-1">Email</label>
                  <input
                    type="email"
                    value={reviewForm.customer_email}
                    onChange={(e) => setReviewForm({ ...reviewForm, customer_email: e.target.value })}
                    className="input-field"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-dark-700 mb-1">Rating</label>
                  <div className="flex gap-1">
                    {[1, 2, 3, 4, 5].map((star) => (
                      <button
                        key={star}
                        type="button"
                        onClick={() => setReviewForm({ ...reviewForm, rating: star })}
                        className="p-1"
                      >
                        <Star
                          className={`w-6 h-6 ${
                            star <= reviewForm.rating ? 'text-yellow-400 fill-yellow-400' : 'text-dark-200'
                          }`}
                        />
                      </button>
                    ))}
                  </div>
                </div>
                <div>
                  <label className="block text-sm font-medium text-dark-700 mb-1">Title</label>
                  <input
                    type="text"
                    value={reviewForm.title}
                    onChange={(e) => setReviewForm({ ...reviewForm, title: e.target.value })}
                    className="input-field"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-dark-700 mb-1">Review</label>
                  <textarea
                    rows={4}
                    value={reviewForm.comment}
                    onChange={(e) => setReviewForm({ ...reviewForm, comment: e.target.value })}
                    className="input-field"
                  />
                </div>
                <button type="submit" className="btn-primary w-full" disabled={submitReview.isPending}>
                  {submitReview.isPending ? 'Submitting...' : 'Submit Review'}
                </button>
              </form>
            </div>
          </div>
        </div>

        {/* Related Products */}
        {relatedProducts && relatedProducts.length > 0 && (
          <div className="mt-16">
            <h2 className="text-2xl font-bold text-dark-900 mb-6">Related Products</h2>
            <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-4 lg:gap-6">
              {relatedProducts.map((product) => (
                <ProductCard key={product.id} product={product} />
              ))}
            </div>
          </div>
        )}
      </div>
    </>
  )
}
