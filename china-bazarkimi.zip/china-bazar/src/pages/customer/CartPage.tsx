import { Helmet } from 'react-helmet-async'
import { Link } from 'react-router-dom'
import { useCartStore } from '@/contexts/CartContext'
import { Minus, Plus, Trash2, ShoppingBag, ArrowRight } from 'lucide-react'
import { formatPrice } from '@/lib/utils'
import toast from 'react-hot-toast'

export default function CartPage() {
  const { items, updateQuantity, removeItem, getTotalPrice, getDiscountedTotal, clearCart } = useCartStore()

  const shippingCost = getTotalPrice() >= 1000 ? 0 : 60
  const total = getTotalPrice() + shippingCost
  const savings = getDiscountedTotal() - getTotalPrice()

  if (items.length === 0) {
    return (
      <>
        <Helmet>
          <title>Cart - China Bazar</title>
        </Helmet>
        <div className="min-h-[60vh] flex items-center justify-center">
          <div className="text-center">
            <ShoppingBag className="w-16 h-16 text-dark-300 mx-auto mb-4" />
            <h1 className="text-2xl font-bold text-dark-900 mb-2">Your Cart is Empty</h1>
            <p className="text-dark-500 mb-6">Looks like you haven't added any products yet.</p>
            <Link to="/shop" className="btn-primary">Start Shopping</Link>
          </div>
        </div>
      </>
    )
  }

  return (
    <>
      <Helmet>
        <title>Cart ({items.length} items) - China Bazar</title>
      </Helmet>

      <div className="section-padding max-w-7xl mx-auto py-8">
        <h1 className="text-2xl lg:text-3xl font-bold text-dark-900 mb-8">Shopping Cart</h1>

        <div className="flex flex-col lg:flex-row gap-8">
          {/* Cart Items */}
          <div className="flex-1 space-y-4">
            {items.map((item) => (
              <div
                key={item.product.id}
                className="flex gap-4 bg-white p-4 rounded-xl border border-dark-100"
              >
                <Link to={`/product/${item.product.slug}`} className="w-24 h-24 shrink-0">
                  <img
                    src={item.product.images[0] || '/placeholder-product.jpg'}
                    alt={item.product.name}
                    className="w-full h-full object-cover rounded-lg"
                  />
                </Link>
                <div className="flex-1 min-w-0">
                  <Link to={`/product/${item.product.slug}`}>
                    <h3 className="font-medium text-dark-900 hover:text-primary-800 transition-colors truncate">
                      {item.product.name}
                    </h3>
                  </Link>
                  <p className="text-sm text-dark-400 mt-0.5">{item.product.brand || 'China Bazar'}</p>
                  <div className="flex items-center justify-between mt-3">
                    <div className="flex items-center border border-dark-200 rounded-lg">
                      <button
                        onClick={() => updateQuantity(item.product.id, item.quantity - 1)}
                        className="p-2 hover:bg-dark-50 transition-colors"
                      >
                        <Minus className="w-4 h-4" />
                      </button>
                      <span className="w-10 text-center text-sm font-medium">{item.quantity}</span>
                      <button
                        onClick={() => {
                          if (item.quantity < item.product.stock_quantity) {
                            updateQuantity(item.product.id, item.quantity + 1)
                          } else {
                            toast.error('Maximum stock reached')
                          }
                        }}
                        className="p-2 hover:bg-dark-50 transition-colors"
                      >
                        <Plus className="w-4 h-4" />
                      </button>
                    </div>
                    <div className="text-right">
                      <p className="font-bold text-primary-800">
                        {formatPrice((item.product.discount_price || item.product.price) * item.quantity)}
                      </p>
                      {item.product.discount_price && (
                        <p className="text-xs text-dark-400 line-through">
                          {formatPrice(item.product.price * item.quantity)}
                        </p>
                      )}
                    </div>
                  </div>
                </div>
                <button
                  onClick={() => {
                    removeItem(item.product.id)
                    toast.success('Item removed from cart')
                  }}
                  className="p-2 text-dark-400 hover:text-red-500 transition-colors self-start"
                >
                  <Trash2 className="w-5 h-5" />
                </button>
              </div>
            ))}

            <button
              onClick={() => {
                clearCart()
                toast.success('Cart cleared')
              }}
              className="text-sm text-red-500 hover:text-red-600 font-medium"
            >
              Clear Cart
            </button>
          </div>

          {/* Order Summary */}
          <div className="lg:w-96 shrink-0">
            <div className="bg-white p-6 rounded-xl border border-dark-100 sticky top-24">
              <h2 className="text-lg font-bold text-dark-900 mb-4">Order Summary</h2>
              <div className="space-y-3 text-sm">
                <div className="flex justify-between text-dark-600">
                  <span>Subtotal</span>
                  <span>{formatPrice(getTotalPrice())}</span>
                </div>
                {savings > 0 && (
                  <div className="flex justify-between text-green-600">
                    <span>Discount</span>
                    <span>-{formatPrice(savings)}</span>
                  </div>
                )}
                <div className="flex justify-between text-dark-600">
                  <span>Shipping</span>
                  <span>{shippingCost === 0 ? 'Free' : formatPrice(shippingCost)}</span>
                </div>
                <div className="border-t border-dark-100 pt-3">
                  <div className="flex justify-between font-bold text-lg text-dark-900">
                    <span>Total</span>
                    <span>{formatPrice(total)}</span>
                  </div>
                </div>
              </div>
              {getTotalPrice() < 1000 && (
                <p className="text-xs text-dark-500 mt-3">
                  Add {formatPrice(1000 - getTotalPrice())} more for free shipping
                </p>
              )}
              <Link
                to="/checkout"
                className="btn-primary w-full mt-6 gap-2"
              >
                Proceed to Checkout
                <ArrowRight className="w-4 h-4" />
              </Link>
              <Link
                to="/shop"
                className="block text-center text-sm text-primary-800 hover:underline mt-4"
              >
                Continue Shopping
              </Link>
            </div>
          </div>
        </div>
      </div>
    </>
  )
}
