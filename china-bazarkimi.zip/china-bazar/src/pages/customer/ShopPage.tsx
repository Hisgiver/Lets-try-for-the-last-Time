import { useState, useEffect } from 'react'
import { Helmet } from 'react-helmet-async'
import { useSearchParams } from 'react-router-dom'
import { useQuery } from '@tanstack/react-query'
import { supabase } from '@/lib/supabase'
import { Search, SlidersHorizontal, X, ChevronDown } from 'lucide-react'
import ProductCard from '@/components/customer/ProductCard'
import { cn } from '@/lib/utils'

export default function ShopPage() {
  const [searchParams, setSearchParams] = useSearchParams()
  const [isFilterOpen, setIsFilterOpen] = useState(false)
  const [searchQuery, setSearchQuery] = useState(searchParams.get('search') || '')

  const categoryFilter = searchParams.get('category') || ''
  const sortBy = searchParams.get('sort') || 'newest'
  const minPrice = searchParams.get('minPrice') || ''
  const maxPrice = searchParams.get('maxPrice') || ''
  const brandFilter = searchParams.get('brand') || ''
  const inStockOnly = searchParams.get('inStock') === 'true'

  const { data: categories } = useQuery({
    queryKey: ['categories'],
    queryFn: async () => {
      const { data } = await supabase.from('categories').select('*').eq('is_active', true).order('sort_order')
      return data || []
    },
  })

  const { data: brands } = useQuery({
    queryKey: ['brands'],
    queryFn: async () => {
      const { data } = await supabase.from('products').select('brand').eq('is_available', true).not('brand', 'is', null)
      const uniqueBrands = [...new Set(data?.map((p) => p.brand).filter(Boolean))]
      return uniqueBrands as string[]
    },
  })

  const { data: products, isLoading } = useQuery({
    queryKey: ['products', 'shop', categoryFilter, sortBy, minPrice, maxPrice, brandFilter, inStockOnly, searchQuery],
    queryFn: async () => {
      let query = supabase
        .from('products')
        .select('*, category:categories(*)')
        .eq('is_available', true)

      if (categoryFilter) {
        const cat = categories?.find((c) => c.slug === categoryFilter)
        if (cat) query = query.eq('category_id', cat.id)
      }

      if (searchQuery) {
        query = query.or(`name.ilike.%${searchQuery}%,description.ilike.%${searchQuery}%,brand.ilike.%${searchQuery}%,tags.cs.{${searchQuery}}`)
      }

      if (minPrice) query = query.gte('price', parseFloat(minPrice))
      if (maxPrice) query = query.lte('price', parseFloat(maxPrice))
      if (brandFilter) query = query.eq('brand', brandFilter)
      if (inStockOnly) query = query.gt('stock_quantity', 0)

      switch (sortBy) {
        case 'price_asc':
          query = query.order('price', { ascending: true })
          break
        case 'price_desc':
          query = query.order('price', { ascending: false })
          break
        case 'best_selling':
          query = query.order('view_count', { ascending: false })
          break
        default:
          query = query.order('created_at', { ascending: false })
      }

      const { data } = await query
      return data || []
    },
  })

  const updateFilter = (key: string, value: string) => {
    const newParams = new URLSearchParams(searchParams)
    if (value) {
      newParams.set(key, value)
    } else {
      newParams.delete(key)
    }
    setSearchParams(newParams)
  }

  const clearFilters = () => {
    setSearchParams(new URLSearchParams())
    setSearchQuery('')
  }

  const hasActiveFilters = categoryFilter || minPrice || maxPrice || brandFilter || inStockOnly || searchQuery

  return (
    <>
      <Helmet>
        <title>Shop - China Bazar</title>
        <meta name="description" content="Browse our collection of premium Chinese products. Filter by category, price, brand and more." />
      </Helmet>

      <div className="bg-dark-50 py-8">
        <div className="section-padding max-w-7xl mx-auto">
          <h1 className="text-3xl font-bold text-dark-900">Shop</h1>
          <p className="text-dark-500 mt-1">{products?.length || 0} products available</p>
        </div>
      </div>

      <div className="section-padding max-w-7xl mx-auto py-8">
        <div className="flex flex-col lg:flex-row gap-8">
          {/* Mobile Filter Toggle */}
          <div className="lg:hidden">
            <button
              onClick={() => setIsFilterOpen(!isFilterOpen)}
              className="flex items-center gap-2 px-4 py-2.5 bg-white border border-dark-200 rounded-lg font-medium"
            >
              <SlidersHorizontal className="w-4 h-4" />
              Filters
              {hasActiveFilters && <span className="w-2 h-2 bg-primary-800 rounded-full" />}
            </button>
          </div>

          {/* Sidebar Filters */}
          <aside className={cn(
            'lg:w-64 shrink-0 space-y-6',
            isFilterOpen ? 'block' : 'hidden lg:block'
          )}>
            {/* Search */}
            <div>
              <h3 className="font-semibold text-dark-900 mb-3">Search</h3>
              <div className="relative">
                <input
                  type="text"
                  placeholder="Search products..."
                  value={searchQuery}
                  onChange={(e) => {
                    setSearchQuery(e.target.value)
                    updateFilter('search', e.target.value)
                  }}
                  className="w-full pl-4 pr-10 py-2.5 border border-dark-200 rounded-lg text-sm"
                />
                <Search className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-dark-400" />
              </div>
            </div>

            {/* Categories */}
            <div>
              <h3 className="font-semibold text-dark-900 mb-3">Categories</h3>
              <div className="space-y-2">
                <button
                  onClick={() => updateFilter('category', '')}
                  className={cn(
                    'block w-full text-left text-sm py-1.5 px-2 rounded transition-colors',
                    !categoryFilter ? 'bg-primary-50 text-primary-800 font-medium' : 'text-dark-600 hover:bg-dark-50'
                  )}
                >
                  All Categories
                </button>
                {categories?.map((cat) => (
                  <button
                    key={cat.id}
                    onClick={() => updateFilter('category', cat.slug)}
                    className={cn(
                      'block w-full text-left text-sm py-1.5 px-2 rounded transition-colors',
                      categoryFilter === cat.slug ? 'bg-primary-50 text-primary-800 font-medium' : 'text-dark-600 hover:bg-dark-50'
                    )}
                  >
                    {cat.name}
                  </button>
                ))}
              </div>
            </div>

            {/* Price Range */}
            <div>
              <h3 className="font-semibold text-dark-900 mb-3">Price Range</h3>
              <div className="flex items-center gap-2">
                <input
                  type="number"
                  placeholder="Min"
                  value={minPrice}
                  onChange={(e) => updateFilter('minPrice', e.target.value)}
                  className="w-full px-3 py-2 border border-dark-200 rounded-lg text-sm"
                />
                <span className="text-dark-400">-</span>
                <input
                  type="number"
                  placeholder="Max"
                  value={maxPrice}
                  onChange={(e) => updateFilter('maxPrice', e.target.value)}
                  className="w-full px-3 py-2 border border-dark-200 rounded-lg text-sm"
                />
              </div>
            </div>

            {/* Brands */}
            {brands && brands.length > 0 && (
              <div>
                <h3 className="font-semibold text-dark-900 mb-3">Brands</h3>
                <div className="space-y-2">
                  <button
                    onClick={() => updateFilter('brand', '')}
                    className={cn(
                      'block w-full text-left text-sm py-1.5 px-2 rounded transition-colors',
                      !brandFilter ? 'bg-primary-50 text-primary-800 font-medium' : 'text-dark-600 hover:bg-dark-50'
                    )}
                  >
                    All Brands
                  </button>
                  {brands.map((brand) => (
                    <button
                      key={brand}
                      onClick={() => updateFilter('brand', brand)}
                      className={cn(
                        'block w-full text-left text-sm py-1.5 px-2 rounded transition-colors',
                        brandFilter === brand ? 'bg-primary-50 text-primary-800 font-medium' : 'text-dark-600 hover:bg-dark-50'
                      )}
                    >
                      {brand}
                    </button>
                  ))}
                </div>
              </div>
            )}

            {/* Availability */}
            <div>
              <h3 className="font-semibold text-dark-900 mb-3">Availability</h3>
              <label className="flex items-center gap-2 cursor-pointer">
                <input
                  type="checkbox"
                  checked={inStockOnly}
                  onChange={(e) => updateFilter('inStock', e.target.checked ? 'true' : '')}
                  className="w-4 h-4 text-primary-800 rounded border-dark-300"
                />
                <span className="text-sm text-dark-600">In Stock Only</span>
              </label>
            </div>

            {hasActiveFilters && (
              <button
                onClick={clearFilters}
                className="flex items-center gap-2 text-sm text-red-500 hover:text-red-600"
              >
                <X className="w-4 h-4" />
                Clear All Filters
              </button>
            )}
          </aside>

          {/* Products Grid */}
          <div className="flex-1">
            {/* Sort Bar */}
            <div className="flex items-center justify-between mb-6">
              <p className="text-sm text-dark-500">
                Showing {products?.length || 0} products
              </p>
              <div className="relative">
                <select
                  value={sortBy}
                  onChange={(e) => updateFilter('sort', e.target.value)}
                  className="appearance-none bg-white border border-dark-200 rounded-lg pl-4 pr-10 py-2 text-sm cursor-pointer"
                >
                  <option value="newest">Newest First</option>
                  <option value="price_asc">Price: Low to High</option>
                  <option value="price_desc">Price: High to Low</option>
                  <option value="best_selling">Best Selling</option>
                </select>
                <ChevronDown className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-dark-400 pointer-events-none" />
              </div>
            </div>

            {isLoading ? (
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-4">
                {[...Array(6)].map((_, i) => (
                  <div key={i} className="animate-pulse">
                    <div className="aspect-square bg-dark-100 rounded-xl mb-3" />
                    <div className="h-4 bg-dark-100 rounded w-3/4 mb-2" />
                    <div className="h-4 bg-dark-100 rounded w-1/2" />
                  </div>
                ))}
              </div>
            ) : products && products.length > 0 ? (
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-4 lg:gap-6">
                {products.map((product) => (
                  <ProductCard key={product.id} product={product} />
                ))}
              </div>
            ) : (
              <div className="text-center py-16">
                <p className="text-dark-500 text-lg">No products found</p>
                <button
                  onClick={clearFilters}
                  className="mt-4 text-primary-800 font-medium hover:underline"
                >
                  Clear filters
                </button>
              </div>
            )}
          </div>
        </div>
      </div>
    </>
  )
}
