import { Helmet } from 'react-helmet-async'
import { useQuery } from '@tanstack/react-query'
import { supabase } from '@/lib/supabase'
import { Link } from 'react-router-dom'
import { ShoppingBag, Truck, Shield, Headphones, ArrowRight, Star, ChevronLeft, ChevronRight } from 'lucide-react'
import ProductCard from '@/components/customer/ProductCard'
import SectionHeader from '@/components/customer/SectionHeader'
import { useRef } from 'react'

export default function HomePage() {
  const scrollRef = useRef<HTMLDivElement>(null)

  const { data: banners } = useQuery({
    queryKey: ['banners', 'hero'],
    queryFn: async () => {
      const { data } = await supabase
        .from('banners')
        .select('*')
        .eq('position', 'hero')
        .eq('is_active', true)
        .order('sort_order')
      return data || []
    },
  })

  const { data: featuredProducts } = useQuery({
    queryKey: ['products', 'featured'],
    queryFn: async () => {
      const { data } = await supabase
        .from('products')
        .select('*, category:categories(*)')
        .eq('is_featured', true)
        .eq('is_available', true)
        .order('created_at', { ascending: false })
        .limit(8)
      return data || []
    },
  })

  const { data: newArrivals } = useQuery({
    queryKey: ['products', 'new'],
    queryFn: async () => {
      const { data } = await supabase
        .from('products')
        .select('*, category:categories(*)')
        .eq('is_new_arrival', true)
        .eq('is_available', true)
        .order('created_at', { ascending: false })
        .limit(8)
      return data || []
    },
  })

  const { data: bestSellers } = useQuery({
    queryKey: ['products', 'best_sellers'],
    queryFn: async () => {
      const { data } = await supabase
        .from('products')
        .select('*, category:categories(*)')
        .eq('is_best_seller', true)
        .eq('is_available', true)
        .order('view_count', { ascending: false })
        .limit(8)
      return data || []
    },
  })

  const { data: categories } = useQuery({
    queryKey: ['categories'],
    queryFn: async () => {
      const { data } = await supabase
        .from('categories')
        .select('*')
        .eq('is_active', true)
        .order('sort_order')
        .limit(6)
      return data || []
    },
  })

  const { data: faqs } = useQuery({
    queryKey: ['faqs', 'home'],
    queryFn: async () => {
      const { data } = await supabase
        .from('faqs')
        .select('*')
        .eq('is_active', true)
        .order('sort_order')
        .limit(4)
      return data || []
    },
  })

  const scroll = (direction: 'left' | 'right') => {
    if (scrollRef.current) {
      const scrollAmount = 320
      scrollRef.current.scrollBy({
        left: direction === 'left' ? -scrollAmount : scrollAmount,
        behavior: 'smooth',
      })
    }
  }

  return (
    <>
      <Helmet>
        <title>China Bazar - Premium Chinese Products in Bangladesh</title>
        <meta name="description" content="Discover premium Chinese products at China Bazar. Best quality electronics, gadgets, home appliances & more. Cash on Delivery available across Bangladesh." />
      </Helmet>

      {/* Hero Banner */}
      <section className="relative bg-dark-950 overflow-hidden">
        {banners && banners.length > 0 ? (
          <div className="relative h-[400px] sm:h-[500px] lg:h-[600px]">
            <img
              src={banners[0].image_url}
              alt={banners[0].title || 'Hero Banner'}
              className="w-full h-full object-cover opacity-60"
            />
            <div className="absolute inset-0 flex items-center section-padding">
              <div className="max-w-7xl mx-auto w-full">
                <div className="max-w-xl">
                  <h1 className="text-4xl sm:text-5xl lg:text-6xl font-bold text-white mb-4 leading-tight">
                    {banners[0].title || 'Premium Chinese Products'}
                  </h1>
                  <p className="text-lg sm:text-xl text-dark-200 mb-8">
                    {banners[0].subtitle || 'Discover quality electronics, gadgets & more at unbeatable prices'}
                  </p>
                  <Link
                    to={banners[0].link_url || '/shop'}
                    className="btn-primary inline-flex items-center gap-2 text-lg"
                  >
                    {banners[0].button_text || 'Shop Now'}
                    <ArrowRight className="w-5 h-5" />
                  </Link>
                </div>
              </div>
            </div>
          </div>
        ) : (
          <div className="relative h-[400px] sm:h-[500px] lg:h-[600px] bg-primary-900">
            <div className="absolute inset-0 flex items-center section-padding">
              <div className="max-w-7xl mx-auto w-full">
                <div className="max-w-xl">
                  <h1 className="text-4xl sm:text-5xl lg:text-6xl font-bold text-white mb-4 leading-tight">
                    Premium Chinese Products
                  </h1>
                  <p className="text-lg sm:text-xl text-primary-100 mb-8">
                    Discover quality electronics, gadgets & more at unbeatable prices
                  </p>
                  <Link to="/shop" className="btn-primary inline-flex items-center gap-2 text-lg">
                    Shop Now
                    <ArrowRight className="w-5 h-5" />
                  </Link>
                </div>
              </div>
            </div>
          </div>
        )}
      </section>

      {/* Features Bar */}
      <section className="bg-white border-b border-dark-100">
        <div className="section-padding max-w-7xl mx-auto py-8">
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-6">
            {[
              { icon: Truck, title: 'Free Shipping', desc: 'On orders over ৳1,000' },
              { icon: Shield, title: 'Quality Guarantee', desc: '100% authentic products' },
              { icon: Headphones, title: '24/7 Support', desc: 'Dedicated support team' },
              { icon: ShoppingBag, title: 'Cash on Delivery', desc: 'Pay when you receive' },
            ].map((feature) => (
              <div key={feature.title} className="flex items-center gap-4">
                <div className="w-12 h-12 bg-primary-50 rounded-xl flex items-center justify-center shrink-0">
                  <feature.icon className="w-6 h-6 text-primary-800" />
                </div>
                <div>
                  <h3 className="font-semibold text-dark-900 text-sm">{feature.title}</h3>
                  <p className="text-dark-400 text-xs">{feature.desc}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Categories */}
      <section className="section-padding max-w-7xl mx-auto py-16">
        <SectionHeader
          title="Shop by Category"
          subtitle="Browse our wide range of product categories"
          action={{ label: 'View All', href: '/shop' }}
        />
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-4">
          {categories?.map((cat) => (
            <Link
              key={cat.id}
              to={`/shop?category=${cat.slug}`}
              className="group text-center"
            >
              <div className="aspect-square rounded-2xl bg-dark-50 overflow-hidden mb-3">
                <img
                  src={cat.image_url || '/placeholder-category.jpg'}
                  alt={cat.name}
                  loading="lazy"
                  className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                />
              </div>
              <h3 className="font-medium text-dark-900 group-hover:text-primary-800 transition-colors text-sm">
                {cat.name}
              </h3>
            </Link>
          ))}
        </div>
      </section>

      {/* Featured Products */}
      {featuredProducts && featuredProducts.length > 0 && (
        <section className="bg-dark-50 py-16">
          <div className="section-padding max-w-7xl mx-auto">
            <SectionHeader
              title="Featured Products"
              subtitle="Handpicked products just for you"
              action={{ label: 'View All', href: '/shop' }}
            />
            <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-4 lg:gap-6">
              {featuredProducts.map((product) => (
                <ProductCard key={product.id} product={product} />
              ))}
            </div>
          </div>
        </section>
      )}

      {/* New Arrivals */}
      {newArrivals && newArrivals.length > 0 && (
        <section className="section-padding max-w-7xl mx-auto py-16">
          <SectionHeader
            title="New Arrivals"
            subtitle="Check out our latest products"
            action={{ label: 'View All', href: '/shop?sort=newest' }}
          />
          <div className="relative">
            <button
              onClick={() => scroll('left')}
              className="absolute left-0 top-1/2 -translate-y-1/2 -translate-x-4 z-10 w-10 h-10 bg-white shadow-lg rounded-full flex items-center justify-center hover:bg-primary-800 hover:text-white transition-colors hidden lg:flex"
            >
              <ChevronLeft className="w-5 h-5" />
            </button>
            <div
              ref={scrollRef}
              className="flex gap-4 lg:gap-6 overflow-x-auto scrollbar-hide pb-4"
              style={{ scrollbarWidth: 'none', msOverflowStyle: 'none' }}
            >
              {newArrivals.map((product) => (
                <div key={product.id} className="w-[260px] sm:w-[280px] shrink-0">
                  <ProductCard product={product} />
                </div>
              ))}
            </div>
            <button
              onClick={() => scroll('right')}
              className="absolute right-0 top-1/2 -translate-y-1/2 translate-x-4 z-10 w-10 h-10 bg-white shadow-lg rounded-full flex items-center justify-center hover:bg-primary-800 hover:text-white transition-colors hidden lg:flex"
            >
              <ChevronRight className="w-5 h-5" />
            </button>
          </div>
        </section>
      )}

      {/* Best Sellers */}
      {bestSellers && bestSellers.length > 0 && (
        <section className="bg-dark-50 py-16">
          <div className="section-padding max-w-7xl mx-auto">
            <SectionHeader
              title="Best Sellers"
              subtitle="Our most popular products"
              action={{ label: 'View All', href: '/shop?sort=best_selling' }}
            />
            <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-4 lg:gap-6">
              {bestSellers.map((product) => (
                <ProductCard key={product.id} product={product} />
              ))}
            </div>
          </div>
        </section>
      )}

      {/* Why Choose Us */}
      <section className="section-padding max-w-7xl mx-auto py-16">
        <div className="text-center mb-12">
          <h2 className="text-2xl lg:text-3xl font-bold text-dark-900 mb-3">Why Choose China Bazar?</h2>
          <p className="text-dark-500 max-w-2xl mx-auto">
            We are committed to providing the best shopping experience with quality products and excellent service.
          </p>
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
          {[
            {
              icon: Star,
              title: 'Premium Quality',
              desc: 'All products are carefully selected and tested for quality assurance.',
            },
            {
              icon: Truck,
              title: 'Fast Delivery',
              desc: 'Quick and reliable delivery service across all districts of Bangladesh.',
            },
            {
              icon: Shield,
              title: 'Secure Shopping',
              desc: 'Your data and transactions are protected with industry-standard security.',
            },
            {
              icon: Headphones,
              title: 'Easy Returns',
              desc: 'Hassle-free return policy within 7 days of delivery.',
            },
          ].map((item) => (
            <div key={item.title} className="text-center p-6 rounded-2xl bg-white border border-dark-100 hover:shadow-lg transition-shadow">
              <div className="w-14 h-14 bg-primary-50 rounded-xl flex items-center justify-center mx-auto mb-4">
                <item.icon className="w-7 h-7 text-primary-800" />
              </div>
              <h3 className="font-semibold text-dark-900 mb-2">{item.title}</h3>
              <p className="text-dark-500 text-sm">{item.desc}</p>
            </div>
          ))}
        </div>
      </section>

      {/* FAQ Preview */}
      {faqs && faqs.length > 0 && (
        <section className="bg-dark-50 py-16">
          <div className="section-padding max-w-7xl mx-auto">
            <SectionHeader
              title="Frequently Asked Questions"
              subtitle="Find answers to common questions"
              action={{ label: 'View All', href: '/faq' }}
            />
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {faqs.map((faq) => (
                <div key={faq.id} className="bg-white p-6 rounded-xl border border-dark-100">
                  <h3 className="font-semibold text-dark-900 mb-2">{faq.question}</h3>
                  <p className="text-dark-500 text-sm">{faq.answer}</p>
                </div>
              ))}
            </div>
          </div>
        </section>
      )}

      {/* CTA Section */}
      <section className="bg-primary-900 py-16">
        <div className="section-padding max-w-7xl mx-auto text-center">
          <h2 className="text-3xl lg:text-4xl font-bold text-white mb-4">
            Ready to Start Shopping?
          </h2>
          <p className="text-primary-100 text-lg mb-8 max-w-2xl mx-auto">
            Browse our collection of premium Chinese products and enjoy cash on delivery across Bangladesh.
          </p>
          <Link to="/shop" className="btn-secondary text-lg inline-flex items-center gap-2">
            Browse Products
            <ArrowRight className="w-5 h-5" />
          </Link>
        </div>
      </section>
    </>
  )
}
