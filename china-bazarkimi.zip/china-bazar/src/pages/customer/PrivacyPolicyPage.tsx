import { Helmet } from 'react-helmet-async'

export default function PrivacyPolicyPage() {
  return (
    <>
      <Helmet>
        <title>Privacy Policy - China Bazar</title>
      </Helmet>
      <div className="section-padding max-w-4xl mx-auto py-12">
        <h1 className="text-3xl font-bold text-dark-900 mb-6">Privacy Policy</h1>
        <div className="prose prose-dark max-w-none">
          <p className="text-dark-600 mb-4">Last updated: {new Date().toLocaleDateString()}</p>
          <p className="text-dark-600 mb-4">At China Bazar, we take your privacy seriously. This Privacy Policy describes how we collect, use, and protect your personal information.</p>
          <h2 className="text-xl font-bold text-dark-900 mt-8 mb-4">Information We Collect</h2>
          <p className="text-dark-600 mb-4">We collect information you provide directly to us, including your name, email address, phone number, shipping address, and payment information when you place an order.</p>
          <h2 className="text-xl font-bold text-dark-900 mt-8 mb-4">How We Use Your Information</h2>
          <p className="text-dark-600 mb-4">We use your information to process orders, communicate with you about your orders, and improve our services. We do not sell or share your personal information with third parties for marketing purposes.</p>
          <h2 className="text-xl font-bold text-dark-900 mt-8 mb-4">Data Security</h2>
          <p className="text-dark-600 mb-4">We implement appropriate security measures to protect your personal information from unauthorized access, alteration, or disclosure.</p>
        </div>
      </div>
    </>
  )
}
