import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query'
import { supabase } from '@/lib/supabase'
import { CheckCircle, XCircle, Trash2, Star } from 'lucide-react'
import toast from 'react-hot-toast'

export default function AdminReviewsPage() {
  const queryClient = useQueryClient()

  const { data: reviews } = useQuery({
    queryKey: ['admin-reviews'],
    queryFn: async () => {
      const { data } = await supabase.from('reviews').select('*, product:products(name)').order('created_at', { ascending: false })
      return data || []
    },
  })

  const updateReview = useMutation({
    mutationFn: async ({ id, is_approved }: { id: string; is_approved: boolean }) => {
      await supabase.from('reviews').update({ is_approved }).eq('id', id)
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['admin-reviews'] })
      toast.success('Review updated')
    },
  })

  const deleteReview = useMutation({
    mutationFn: async (id: string) => {
      await supabase.from('reviews').delete().eq('id', id)
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['admin-reviews'] })
      toast.success('Review deleted')
    },
  })

  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-bold text-dark-900">Reviews</h1>
      <div className="bg-white rounded-xl border border-dark-100 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead className="bg-dark-50 text-dark-600"><tr><th className="text-left px-4 py-3">Product</th><th className="text-left px-4 py-3">Customer</th><th className="text-left px-4 py-3">Rating</th><th className="text-left px-4 py-3">Comment</th><th className="text-left px-4 py-3">Status</th><th className="text-right px-4 py-3">Actions</th></tr></thead>
            <tbody className="divide-y divide-dark-100">
              {reviews?.map((review: any) => (
                <tr key={review.id} className="hover:bg-dark-50">
                  <td className="px-4 py-3 text-dark-900">{review.product?.name}</td>
                  <td className="px-4 py-3"><p className="text-dark-900">{review.customer_name}</p><p className="text-xs text-dark-500">{review.customer_email}</p></td>
                  <td className="px-4 py-3"><div className="flex gap-0.5">{[...Array(5)].map((_, i) => <Star key={i} className={`w-4 h-4 ${i < review.rating ? 'text-yellow-400 fill-yellow-400' : 'text-dark-200'}`} />)}</div></td>
                  <td className="px-4 py-3 max-w-xs"><p className="truncate">{review.comment}</p></td>
                  <td className="px-4 py-3"><span className={`text-xs px-2 py-1 rounded-full ${review.is_approved ? 'bg-green-100 text-green-800' : 'bg-yellow-100 text-yellow-800'}`}>{review.is_approved ? 'Approved' : 'Pending'}</span></td>
                  <td className="px-4 py-3 text-right">
                    {!review.is_approved && <button onClick={() => updateReview.mutate({ id: review.id, is_approved: true })} className="p-1.5 text-green-600 hover:text-green-700"><CheckCircle className="w-4 h-4" /></button>}
                    {review.is_approved && <button onClick={() => updateReview.mutate({ id: review.id, is_approved: false })} className="p-1.5 text-yellow-600 hover:text-yellow-700"><XCircle className="w-4 h-4" /></button>}
                    <button onClick={() => deleteReview.mutate(review.id)} className="p-1.5 text-red-500 hover:text-red-600"><Trash2 className="w-4 h-4" /></button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  )
}
