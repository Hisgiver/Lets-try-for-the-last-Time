import { useState } from 'react'
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query'
import { supabase } from '@/lib/supabase'
import { Plus, Pencil, Trash2, X } from 'lucide-react'
import toast from 'react-hot-toast'

export default function AdminBannersPage() {
  const queryClient = useQueryClient()
  const [isModalOpen, setIsModalOpen] = useState(false)
  const [editingBanner, setEditingBanner] = useState<any>(null)
  const [formData, setFormData] = useState({ title: '', subtitle: '', image_url: '', link_url: '', button_text: '', position: 'hero', sort_order: '0', is_active: true })

  const { data: banners } = useQuery({
    queryKey: ['admin-banners'],
    queryFn: async () => {
      const { data } = await supabase.from('banners').select('*').order('sort_order')
      return data || []
    },
  })

  const saveBanner = useMutation({
    mutationFn: async () => {
      const data = { ...formData, sort_order: parseInt(formData.sort_order) }
      if (editingBanner) {
        await supabase.from('banners').update(data).eq('id', editingBanner.id)
      } else {
        await supabase.from('banners').insert(data)
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['admin-banners'] })
      toast.success(editingBanner ? 'Banner updated' : 'Banner created')
      closeModal()
    },
  })

  const deleteBanner = useMutation({
    mutationFn: async (id: string) => {
      await supabase.from('banners').delete().eq('id', id)
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['admin-banners'] })
      toast.success('Banner deleted')
    },
  })

  const openModal = (banner?: any) => {
    if (banner) {
      setEditingBanner(banner)
      setFormData({ title: banner.title || '', subtitle: banner.subtitle || '', image_url: banner.image_url, link_url: banner.link_url || '', button_text: banner.button_text || '', position: banner.position, sort_order: banner.sort_order.toString(), is_active: banner.is_active })
    } else {
      setEditingBanner(null)
      setFormData({ title: '', subtitle: '', image_url: '', link_url: '', button_text: '', position: 'hero', sort_order: '0', is_active: true })
    }
    setIsModalOpen(true)
  }

  const closeModal = () => { setIsModalOpen(false); setEditingBanner(null) }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-bold text-dark-900">Banners</h1>
        <button onClick={() => openModal()} className="btn-primary gap-2"><Plus className="w-4 h-4" /> Add Banner</button>
      </div>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {banners?.map((banner: any) => (
          <div key={banner.id} className="bg-white rounded-xl border border-dark-100 overflow-hidden group">
            <div className="aspect-video relative">
              <img src={banner.image_url} alt={banner.title} className="w-full h-full object-cover" />
              <div className="absolute inset-0 bg-black/50 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center gap-2">
                <button onClick={() => openModal(banner)} className="p-2 bg-white rounded-full hover:bg-primary-800 hover:text-white transition-colors"><Pencil className="w-4 h-4" /></button>
                <button onClick={() => deleteBanner.mutate(banner.id)} className="p-2 bg-white rounded-full hover:bg-red-500 hover:text-white transition-colors"><Trash2 className="w-4 h-4" /></button>
              </div>
            </div>
            <div className="p-4">
              <h3 className="font-medium text-dark-900">{banner.title || 'Untitled'}</h3>
              <p className="text-xs text-dark-500">{banner.position} • {banner.is_active ? 'Active' : 'Inactive'}</p>
            </div>
          </div>
        ))}
      </div>
      {isModalOpen && (
        <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl w-full max-w-lg">
            <div className="p-6 border-b border-dark-100 flex justify-between"><h2 className="text-xl font-bold">{editingBanner ? 'Edit' : 'Add'} Banner</h2><button onClick={closeModal}><X className="w-5 h-5" /></button></div>
            <form onSubmit={(e) => { e.preventDefault(); saveBanner.mutate() }} className="p-6 space-y-4">
              <div><label className="block text-sm font-medium mb-1">Image URL *</label><input required value={formData.image_url} onChange={e => setFormData({...formData, image_url: e.target.value})} className="input-field" /></div>
              <div><label className="block text-sm font-medium mb-1">Title</label><input value={formData.title} onChange={e => setFormData({...formData, title: e.target.value})} className="input-field" /></div>
              <div><label className="block text-sm font-medium mb-1">Subtitle</label><input value={formData.subtitle} onChange={e => setFormData({...formData, subtitle: e.target.value})} className="input-field" /></div>
              <div><label className="block text-sm font-medium mb-1">Link URL</label><input value={formData.link_url} onChange={e => setFormData({...formData, link_url: e.target.value})} className="input-field" /></div>
              <div><label className="block text-sm font-medium mb-1">Button Text</label><input value={formData.button_text} onChange={e => setFormData({...formData, button_text: e.target.value})} className="input-field" /></div>
              <div><label className="block text-sm font-medium mb-1">Position</label><select value={formData.position} onChange={e => setFormData({...formData, position: e.target.value})} className="input-field"><option value="hero">Hero</option><option value="promo">Promotional</option></select></div>
              <div><label className="block text-sm font-medium mb-1">Sort Order</label><input type="number" value={formData.sort_order} onChange={e => setFormData({...formData, sort_order: e.target.value})} className="input-field" /></div>
              <label className="flex items-center gap-2"><input type="checkbox" checked={formData.is_active} onChange={e => setFormData({...formData, is_active: e.target.checked})} /> Active</label>
              <div className="flex justify-end gap-3 pt-4">
                <button type="button" onClick={closeModal} className="px-4 py-2 border border-dark-200 rounded-lg">Cancel</button>
                <button type="submit" disabled={saveBanner.isPending} className="btn-primary">{saveBanner.isPending ? 'Saving...' : 'Save'}</button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  )
}
