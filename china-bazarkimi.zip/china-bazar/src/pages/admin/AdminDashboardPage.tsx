import { useQuery } from '@tanstack/react-query'
import { supabase } from '@/lib/supabase'
import { Package, ShoppingBag, Users, DollarSign } from 'lucide-react'
import { formatPrice } from '@/lib/utils'
import { Link } from 'react-router-dom'

export default function AdminDashboardPage() {
  const { data: stats } = useQuery({
    queryKey: ['admin-stats'],
    queryFn: async () => {
      const [
        { count: totalProducts },
        { count: totalOrders },
        { count: pendingOrders },
        { data: recentOrders },
        { data: lowStockProducts },
      ] = await Promise.all([
        supabase.from('products').select('*', { count: 'exact', head: true }),
        supabase.from('orders').select('*', { count: 'exact', head: true }),
        supabase.from('orders').select('*', { count: 'exact', head: true }).eq('status', 'pending'),
        supabase.from('orders').select('*, order_items(*)').order('created_at', { ascending: false }).limit(5),
        supabase.from('products').select('*').lte('stock_quantity', 5).gt('stock_quantity', 0).limit(5),
      ])
      return { totalProducts, totalOrders, pendingOrders, recentOrders, lowStockProducts }
    },
  })

  const statCards = [
    { label: 'Total Products', value: stats?.totalProducts || 0, icon: Package, color: 'bg-blue-50 text-blue-800' },
    { label: 'Total Orders', value: stats?.totalOrders || 0, icon: ShoppingBag, color: 'bg-green-50 text-green-800' },
    { label: 'Pending Orders', value: stats?.pendingOrders || 0, icon: Users, color: 'bg-yellow-50 text-yellow-800' },
    { label: 'Revenue', value: '৳0', icon: DollarSign, color: 'bg-purple-50 text-purple-800' },
  ]

  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-bold text-dark-900">Dashboard</h1>
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {statCards.map((stat) => (
          <div key={stat.label} className="bg-white p-6 rounded-xl border border-dark-100">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-dark-500">{stat.label}</p>
                <p className="text-2xl font-bold text-dark-900 mt-1">{stat.value}</p>
              </div>
              <div className={`w-12 h-12 rounded-xl flex items-center justify-center ${stat.color}`}>
                <stat.icon className="w-6 h-6" />
              </div>
            </div>
          </div>
        ))}
      </div>
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-white rounded-xl border border-dark-100 overflow-hidden">
          <div className="p-6 border-b border-dark-100 flex items-center justify-between">
            <h2 className="font-bold text-dark-900">Recent Orders</h2>
            <Link to="/admin/orders" className="text-sm text-primary-800 hover:underline">View All</Link>
          </div>
          <div className="divide-y divide-dark-50">
            {stats?.recentOrders?.map((order: any) => (
              <div key={order.id} className="p-4 flex items-center justify-between">
                <div>
                  <p className="font-medium text-dark-900 text-sm">{order.order_number}</p>
                  <p className="text-xs text-dark-500">{order.customer_name}</p>
                </div>
                <div className="text-right">
                  <p className="font-bold text-primary-800 text-sm">{formatPrice(order.total_amount)}</p>
                  <span className={`text-xs px-2 py-0.5 rounded-full ${
                    order.status === 'pending' ? 'bg-yellow-100 text-yellow-800' :
                    order.status === 'delivered' ? 'bg-green-100 text-green-800' :
                    'bg-blue-100 text-blue-800'
                  }`}>{order.status}</span>
                </div>
              </div>
            ))}
            {(!stats?.recentOrders || stats.recentOrders.length === 0) && (
              <p className="p-4 text-dark-500 text-sm text-center">No orders yet</p>
            )}
          </div>
        </div>
        <div className="bg-white rounded-xl border border-dark-100 overflow-hidden">
          <div className="p-6 border-b border-dark-100 flex items-center justify-between">
            <h2 className="font-bold text-dark-900">Low Stock Alert</h2>
            <Link to="/admin/products" className="text-sm text-primary-800 hover:underline">Manage</Link>
          </div>
          <div className="divide-y divide-dark-50">
            {stats?.lowStockProducts?.map((product: any) => (
              <div key={product.id} className="p-4 flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <img src={product.images[0]} alt="" className="w-10 h-10 object-cover rounded-lg" />
                  <div>
                    <p className="font-medium text-dark-900 text-sm">{product.name}</p>
                    <p className="text-xs text-dark-500">SKU: {product.sku}</p>
                  </div>
                </div>
                <span className="text-sm font-bold text-red-600">{product.stock_quantity} left</span>
              </div>
            ))}
            {(!stats?.lowStockProducts || stats.lowStockProducts.length === 0) && (
              <p className="p-4 text-dark-500 text-sm text-center">All products well stocked</p>
            )}
          </div>
        </div>
      </div>
    </div>
  )
}
