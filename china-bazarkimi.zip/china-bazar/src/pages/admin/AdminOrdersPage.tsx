import { useState } from 'react'
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query'
import { supabase } from '@/lib/supabase'
import { Search, Eye, XCircle } from 'lucide-react'
import { formatPrice, orderStatusLabels, orderStatusColors } from '@/lib/utils'
import toast from 'react-hot-toast'

const statusOptions = ['pending', 'confirmed', 'processing', 'shipped', 'delivered', 'cancelled']

export default function AdminOrdersPage() {
  const queryClient = useQueryClient()
  const [searchQuery, setSearchQuery] = useState('')
  const [statusFilter, setStatusFilter] = useState('')
  const [selectedOrder, setSelectedOrder] = useState<any>(null)

  const { data: orders } = useQuery({
    queryKey: ['admin-orders', searchQuery, statusFilter],
    queryFn: async () => {
      let query = supabase.from('orders').select('*, order_items(*)').order('created_at', { ascending: false })
      if (searchQuery) query = query.or(`order_number.ilike.%${searchQuery}%,customer_name.ilike.%${searchQuery}%,customer_phone.ilike.%${searchQuery}%`)
      if (statusFilter) query = query.eq('status', statusFilter)
      const { data } = await query
      return data || []
    },
  })

  const updateStatus = useMutation({
    mutationFn: async ({ id, status }: { id: string; status: string }) => {
      await supabase.from('orders').update({ status }).eq('id', id)
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['admin-orders'] })
      toast.success('Order status updated')
    },
  })

  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-bold text-dark-900">Orders</h1>
      <div className="flex flex-col sm:flex-row gap-4">
        <div className="relative flex-1 max-w-sm">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-dark-400" />
          <input type="text" placeholder="Search orders..." value={searchQuery} onChange={e => setSearchQuery(e.target.value)} className="w-full pl-10 pr-4 py-2 border border-dark-200 rounded-lg text-sm" />
        </div>
        <select value={statusFilter} onChange={e => setStatusFilter(e.target.value)} className="px-4 py-2 border border-dark-200 rounded-lg text-sm">
          <option value="">All Statuses</option>
          {statusOptions.map(s => <option key={s} value={s}>{orderStatusLabels[s as keyof typeof orderStatusLabels]}</option>)}
        </select>
      </div>
      <div className="bg-white rounded-xl border border-dark-100 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead className="bg-dark-50 text-dark-600"><tr><th className="text-left px-4 py-3">Order</th><th className="text-left px-4 py-3">Customer</th><th className="text-left px-4 py-3">Total</th><th className="text-left px-4 py-3">Status</th><th className="text-left px-4 py-3">Date</th><th className="text-right px-4 py-3">Actions</th></tr></thead>
            <tbody className="divide-y divide-dark-100">
              {orders?.map((order: any) => (
                <tr key={order.id} className="hover:bg-dark-50">
                  <td className="px-4 py-3"><p className="font-medium text-dark-900 text-sm">{order.order_number}</p><p className="text-xs text-dark-500">{order.payment_method.toUpperCase()}</p></td>
                  <td className="px-4 py-3"><p className="text-dark-900">{order.customer_name}</p><p className="text-xs text-dark-500">{order.customer_phone}</p></td>
                  <td className="px-4 py-3 font-bold text-primary-800">{formatPrice(order.total_amount)}</td>
                  <td className="px-4 py-3">
                    <select value={order.status} onChange={e => updateStatus.mutate({ id: order.id, status: e.target.value })} className={`text-xs px-2 py-1 rounded-full border-0 cursor-pointer ${orderStatusColors[order.status as keyof typeof orderStatusColors]}`}>
                      {statusOptions.map(s => <option key={s} value={s}>{orderStatusLabels[s as keyof typeof orderStatusLabels]}</option>)}
                    </select>
                  </td>
                  <td className="px-4 py-3 text-dark-500">{new Date(order.created_at).toLocaleDateString()}</td>
                  <td className="px-4 py-3 text-right"><button onClick={() => setSelectedOrder(order)} className="p-1.5 text-dark-400 hover:text-primary-800"><Eye className="w-4 h-4" /></button></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
      {selectedOrder && (
        <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl w-full max-w-2xl max-h-[90vh] overflow-y-auto">
            <div className="p-6 border-b border-dark-100 flex justify-between items-center">
              <h2 className="text-xl font-bold">Order {selectedOrder.order_number}</h2>
              <button onClick={() => setSelectedOrder(null)} className="p-2 hover:bg-dark-50 rounded-lg"><XCircle className="w-5 h-5" /></button>
            </div>
            <div className="p-6 space-y-6">
              <div className="grid grid-cols-2 gap-4">
                <div><p className="text-sm text-dark-500">Customer</p><p className="font-medium">{selectedOrder.customer_name}</p></div>
                <div><p className="text-sm text-dark-500">Phone</p><p className="font-medium">{selectedOrder.customer_phone}</p></div>
                <div><p className="text-sm text-dark-500">Email</p><p className="font-medium">{selectedOrder.customer_email}</p></div>
                <div><p className="text-sm text-dark-500">Date</p><p className="font-medium">{new Date(selectedOrder.created_at).toLocaleString()}</p></div>
              </div>
              <div><p className="text-sm text-dark-500">Address</p><p className="font-medium">{selectedOrder.customer_address}</p><p>{selectedOrder.area_upazila}, {selectedOrder.district}</p></div>
              {selectedOrder.order_notes && <div className="bg-yellow-50 p-3 rounded-lg"><p className="text-sm text-yellow-800">{selectedOrder.order_notes}</p></div>}
              <div>
                <h3 className="font-semibold mb-3">Items</h3>
                <div className="space-y-2">
                  {selectedOrder.order_items?.map((item: any) => (
                    <div key={item.id} className="flex items-center gap-3 p-3 bg-dark-50 rounded-lg">
                      <img src={item.product_image} alt="" className="w-12 h-12 object-cover rounded" />
                      <div className="flex-1"><p className="text-sm font-medium">{item.product_name}</p><p className="text-xs text-dark-500">Qty: {item.quantity}</p></div>
                      <p className="font-bold text-sm">{formatPrice(item.total_price)}</p>
                    </div>
                  ))}
                </div>
              </div>
              <div className="border-t border-dark-100 pt-4 space-y-2">
                <div className="flex justify-between text-sm"><span>Subtotal</span><span>{formatPrice(selectedOrder.subtotal)}</span></div>
                <div className="flex justify-between text-sm"><span>Shipping</span><span>{selectedOrder.shipping_cost === 0 ? 'Free' : formatPrice(selectedOrder.shipping_cost)}</span></div>
                <div className="flex justify-between font-bold text-lg"><span>Total</span><span>{formatPrice(selectedOrder.total_amount)}</span></div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}
