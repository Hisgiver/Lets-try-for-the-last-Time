import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query'
import { supabase } from '@/lib/supabase'
import { Save } from 'lucide-react'
import toast from 'react-hot-toast'

export default function AdminSettingsPage() {
  const queryClient = useQueryClient()

  const { data: settings } = useQuery({
    queryKey: ['admin-settings'],
    queryFn: async () => {
      const { data } = await supabase.from('settings').select('*').order('group_name')
      return data || []
    },
  })

  const updateSetting = useMutation({
    mutationFn: async ({ id, value }: { id: string; value: string }) => {
      await supabase.from('settings').update({ value }).eq('id', id)
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['admin-settings'] })
      toast.success('Settings saved')
    },
  })

  const groupedSettings = settings?.reduce((acc: any, setting: any) => {
    if (!acc[setting.group_name]) acc[setting.group_name] = []
    acc[setting.group_name].push(setting)
    return acc
  }, {})

  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-bold text-dark-900">Settings</h1>
      <div className="space-y-6">
        {groupedSettings && Object.entries(groupedSettings).map(([group, items]: [string, any]) => (
          <div key={group} className="bg-white rounded-xl border border-dark-100 p-6">
            <h2 className="text-lg font-bold text-dark-900 capitalize mb-4">{group} Settings</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {items.map((setting: any) => (
                <div key={setting.id}>
                  <label className="block text-sm font-medium text-dark-700 mb-1 capitalize">{setting.key.replace(/_/g, ' ')}</label>
                  <div className="flex gap-2">
                    <input
                      type="text"
                      defaultValue={setting.value || ''}
                      onBlur={(e) => updateSetting.mutate({ id: setting.id, value: e.target.value })}
                      className="input-field flex-1"
                    />
                  </div>
                </div>
              ))}
            </div>
          </div>
        ))}
      </div>
    </div>
  )
}
