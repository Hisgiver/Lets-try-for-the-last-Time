import { useState } from 'react'
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query'
import { supabase } from '@/lib/supabase'
import { Plus, Pencil, Trash2, X } from 'lucide-react'
import toast from 'react-hot-toast'

export default function AdminFAQsPage() {
  const queryClient = useQueryClient()
  const [isModalOpen, setIsModalOpen] = useState(false)
  const [editingFAQ, setEditingFAQ] = useState<any>(null)
  const [formData, setFormData] = useState({ question: '', answer: '', sort_order: '0', is_active: true })

  const { data: faqs } = useQuery({
    queryKey: ['admin-faqs'],
    queryFn: async () => {
      const { data } = await supabase.from('faqs').select('*').order('sort_order')
      return data || []
    },
  })

  const saveFAQ = useMutation({
    mutationFn: async () => {
      const data = { ...formData, sort_order: parseInt(formData.sort_order) }
      if (editingFAQ) {
        await supabase.from('faqs').update(data).eq('id', editingFAQ.id)
      } else {
        await supabase.from('faqs').insert(data)
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['admin-faqs'] })
      toast.success(editingFAQ ? 'FAQ updated' : 'FAQ created')
      closeModal()
    },
  })

  const deleteFAQ = useMutation({
    mutationFn: async (id: string) => {
      await supabase.from('faqs').delete().eq('id', id)
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['admin-faqs'] })
      toast.success('FAQ deleted')
    },
  })

  const openModal = (faq?: any) => {
    if (faq) {
      setEditingFAQ(faq)
      setFormData({ question: faq.question, answer: faq.answer, sort_order: faq.sort_order.toString(), is_active: faq.is_active })
    } else {
      setEditingFAQ(null)
      setFormData({ question: '', answer: '', sort_order: '0', is_active: true })
    }
    setIsModalOpen(true)
  }

  const closeModal = () => { setIsModalOpen(false); setEditingFAQ(null) }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-bold text-dark-900">FAQs</h1>
        <button onClick={() => openModal()} className="btn-primary gap-2"><Plus className="w-4 h-4" /> Add FAQ</button>
      </div>
      <div className="bg-white rounded-xl border border-dark-100 overflow-hidden">
        <table className="w-full text-sm">
          <thead className="bg-dark-50 text-dark-600"><tr><th className="text-left px-4 py-3">Question</th><th className="text-left px-4 py-3">Answer</th><th className="text-left px-4 py-3">Status</th><th className="text-right px-4 py-3">Actions</th></tr></thead>
          <tbody className="divide-y divide-dark-100">
            {faqs?.map((faq: any) => (
              <tr key={faq.id} className="hover:bg-dark-50">
                <td className="px-4 py-3 font-medium text-dark-900 max-w-xs truncate">{faq.question}</td>
                <td className="px-4 py-3 text-dark-500 max-w-xs truncate">{faq.answer}</td>
                <td className="px-4 py-3"><span className={`text-xs px-2 py-1 rounded-full ${faq.is_active ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'}`}>{faq.is_active ? 'Active' : 'Inactive'}</span></td>
                <td className="px-4 py-3 text-right">
                  <button onClick={() => openModal(faq)} className="p-1.5 text-dark-400 hover:text-primary-800"><Pencil className="w-4 h-4" /></button>
                  <button onClick={() => deleteFAQ.mutate(faq.id)} className="p-1.5 text-dark-400 hover:text-red-500"><Trash2 className="w-4 h-4" /></button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      {isModalOpen && (
        <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl w-full max-w-lg">
            <div className="p-6 border-b border-dark-100 flex justify-between"><h2 className="text-xl font-bold">{editingFAQ ? 'Edit' : 'Add'} FAQ</h2><button onClick={closeModal}><X className="w-5 h-5" /></button></div>
            <form onSubmit={(e) => { e.preventDefault(); saveFAQ.mutate() }} className="p-6 space-y-4">
              <div><label className="block text-sm font-medium mb-1">Question *</label><input required value={formData.question} onChange={e => setFormData({...formData, question: e.target.value})} className="input-field" /></div>
              <div><label className="block text-sm font-medium mb-1">Answer *</label><textarea required rows={4} value={formData.answer} onChange={e => setFormData({...formData, answer: e.target.value})} className="input-field" /></div>
              <div><label className="block text-sm font-medium mb-1">Sort Order</label><input type="number" value={formData.sort_order} onChange={e => setFormData({...formData, sort_order: e.target.value})} className="input-field" /></div>
              <label className="flex items-center gap-2"><input type="checkbox" checked={formData.is_active} onChange={e => setFormData({...formData, is_active: e.target.checked})} /> Active</label>
              <div className="flex justify-end gap-3 pt-4">
                <button type="button" onClick={closeModal} className="px-4 py-2 border border-dark-200 rounded-lg">Cancel</button>
                <button type="submit" disabled={saveFAQ.isPending} className="btn-primary">{saveFAQ.isPending ? 'Saving...' : 'Save'}</button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  )
}
