import { useState } from 'react'
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query'
import { supabase } from '@/lib/supabase'
import { Plus, Pencil, Trash2, Search, X, ImageIcon } from 'lucide-react'
import { formatPrice, generateSlug } from '@/lib/utils'
import toast from 'react-hot-toast'
import type { Product, Category } from '@/types'

export default function AdminProductsPage() {
  const queryClient = useQueryClient()
  const [searchQuery, setSearchQuery] = useState('')
  const [isModalOpen, setIsModalOpen] = useState(false)
  const [editingProduct, setEditingProduct] = useState<Product | null>(null)
  const [imageFiles, setImageFiles] = useState<File[]>([])
  const [formData, setFormData] = useState({
    name: '', description: '', short_description: '', category_id: '', subcategory_id: '',
    price: '', discount_price: '', sku: '', brand: '', stock_quantity: '', tags: '',
    is_featured: false, is_new_arrival: false, is_best_seller: false, is_available: true,
    specifications: {} as Record<string, string>,
  })

  const { data: products } = useQuery({
    queryKey: ['admin-products', searchQuery],
    queryFn: async () => {
      let query = supabase.from('products').select('*, category:categories(*)').order('created_at', { ascending: false })
      if (searchQuery) query = query.ilike('name', `%${searchQuery}%`)
      const { data } = await query
      return data || []
    },
  })

  const { data: categories } = useQuery({
    queryKey: ['admin-categories'],
    queryFn: async () => {
      const { data } = await supabase.from('categories').select('*').eq('is_active', true)
      return data || []
    },
  })

  const { data: subcategories } = useQuery({
    queryKey: ['admin-subcategories', formData.category_id],
    queryFn: async () => {
      if (!formData.category_id) return []
      const { data } = await supabase.from('subcategories').select('*').eq('category_id', formData.category_id).eq('is_active', true)
      return data || []
    },
    enabled: !!formData.category_id,
  })

  const uploadImages = async (files: File[]): Promise<string[]> => {
    const urls: string[] = []
    for (const file of files) {
      const fileExt = file.name.split('.').pop()
      const fileName = `${Date.now()}-${Math.random().toString(36).substring(2)}.${fileExt}`
      const { error } = await supabase.storage.from('products').upload(fileName, file)
      if (error) throw error
      const { data: { publicUrl } } = supabase.storage.from('products').getPublicUrl(fileName)
      urls.push(publicUrl)
    }
    return urls
  }

  const saveProduct = useMutation({
    mutationFn: async () => {
      const slug = generateSlug(formData.name)
      let imageUrls: string[] = editingProduct?.images || []
      if (imageFiles.length > 0) {
        const newUrls = await uploadImages(imageFiles)
        imageUrls = editingProduct ? [...imageUrls, ...newUrls] : newUrls
      }
      const productData = {
        name: formData.name, slug: editingProduct ? editingProduct.slug : slug,
        description: formData.description, short_description: formData.short_description,
        category_id: formData.category_id || null, subcategory_id: formData.subcategory_id || null,
        price: parseFloat(formData.price), discount_price: formData.discount_price ? parseFloat(formData.discount_price) : null,
        sku: formData.sku || null, brand: formData.brand || null,
        stock_quantity: parseInt(formData.stock_quantity) || 0,
        is_available: formData.is_available, is_featured: formData.is_featured,
        is_new_arrival: formData.is_new_arrival, is_best_seller: formData.is_best_seller,
        images: imageUrls, tags: formData.tags.split(',').map(t => t.trim()).filter(Boolean),
        specifications: formData.specifications,
      }
      if (editingProduct) {
        const { error } = await supabase.from('products').update(productData).eq('id', editingProduct.id)
        if (error) throw error
      } else {
        const { error } = await supabase.from('products').insert(productData)
        if (error) throw error
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['admin-products'] })
      toast.success(editingProduct ? 'Product updated' : 'Product created')
      closeModal()
    },
    onError: () => toast.error('Failed to save product'),
  })

  const deleteProduct = useMutation({
    mutationFn: async (id: string) => {
      await supabase.from('products').delete().eq('id', id)
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['admin-products'] })
      toast.success('Product deleted')
    },
  })

  const openModal = (product?: Product) => {
    if (product) {
      setEditingProduct(product)
      setFormData({
        name: product.name, description: product.description || '', short_description: product.short_description || '',
        category_id: product.category_id || '', subcategory_id: product.subcategory_id || '',
        price: product.price.toString(), discount_price: product.discount_price?.toString() || '',
        sku: product.sku || '', brand: product.brand || '', stock_quantity: product.stock_quantity.toString(),
        tags: product.tags.join(', '), is_featured: product.is_featured, is_new_arrival: product.is_new_arrival,
        is_best_seller: product.is_best_seller, is_available: product.is_available,
        specifications: product.specifications,
      })
    } else {
      setEditingProduct(null)
      setFormData({
        name: '', description: '', short_description: '', category_id: '', subcategory_id: '',
        price: '', discount_price: '', sku: '', brand: '', stock_quantity: '', tags: '',
        is_featured: false, is_new_arrival: false, is_best_seller: false, is_available: true,
        specifications: {},
      })
    }
    setImageFiles([])
    setIsModalOpen(true)
  }

  const closeModal = () => { setIsModalOpen(false); setEditingProduct(null); setImageFiles([]) }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-bold text-dark-900">Products</h1>
        <button onClick={() => openModal()} className="btn-primary gap-2"><Plus className="w-4 h-4" /> Add Product</button>
      </div>
      <div className="bg-white rounded-xl border border-dark-100">
        <div className="p-4 border-b border-dark-100">
          <div className="relative max-w-sm">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-dark-400" />
            <input type="text" placeholder="Search products..." value={searchQuery} onChange={(e) => setSearchQuery(e.target.value)} className="w-full pl-10 pr-4 py-2 border border-dark-200 rounded-lg text-sm" />
          </div>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead className="bg-dark-50 text-dark-600">
              <tr><th className="text-left px-4 py-3 font-medium">Product</th><th className="text-left px-4 py-3 font-medium">Price</th><th className="text-left px-4 py-3 font-medium">Stock</th><th className="text-left px-4 py-3 font-medium">Status</th><th className="text-right px-4 py-3 font-medium">Actions</th></tr>
            </thead>
            <tbody className="divide-y divide-dark-100">
              {products?.map((product: any) => (
                <tr key={product.id} className="hover:bg-dark-50">
                  <td className="px-4 py-3">
                    <div className="flex items-center gap-3">
                      <img src={product.images[0]} alt="" className="w-10 h-10 object-cover rounded-lg" />
                      <div><p className="font-medium text-dark-900 text-sm">{product.name}</p><p className="text-xs text-dark-500">{product.category?.name}</p></div>
                    </div>
                  </td>
                  <td className="px-4 py-3">
                    <div><p className="font-medium text-primary-800">{formatPrice(product.discount_price || product.price)}</p>{product.discount_price && <p className="text-xs text-dark-400 line-through">{formatPrice(product.price)}</p>}</div>
                  </td>
                  <td className="px-4 py-3">{product.stock_quantity}</td>
                  <td className="px-4 py-3"><span className={`text-xs px-2 py-1 rounded-full ${product.is_available ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'}`}>{product.is_available ? 'Active' : 'Inactive'}</span></td>
                  <td className="px-4 py-3 text-right">
                    <button onClick={() => openModal(product)} className="p-1.5 text-dark-400 hover:text-primary-800"><Pencil className="w-4 h-4" /></button>
                    <button onClick={() => deleteProduct.mutate(product.id)} className="p-1.5 text-dark-400 hover:text-red-500"><Trash2 className="w-4 h-4" /></button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
      {isModalOpen && (
        <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl w-full max-w-3xl max-h-[90vh] overflow-y-auto">
            <div className="p-6 border-b border-dark-100 flex items-center justify-between">
              <h2 className="text-xl font-bold">{editingProduct ? 'Edit Product' : 'Add Product'}</h2>
              <button onClick={closeModal}><X className="w-5 h-5" /></button>
            </div>
            <form onSubmit={(e) => { e.preventDefault(); saveProduct.mutate() }} className="p-6 space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="sm:col-span-2"><label className="block text-sm font-medium mb-1">Product Name *</label><input required value={formData.name} onChange={e => setFormData({...formData, name: e.target.value})} className="input-field" /></div>
                <div><label className="block text-sm font-medium mb-1">Category</label><select value={formData.category_id} onChange={e => setFormData({...formData, category_id: e.target.value, subcategory_id: ''})} className="input-field"><option value="">Select Category</option>{categories?.map((c: Category) => <option key={c.id} value={c.id}>{c.name}</option>)}</select></div>
                <div><label className="block text-sm font-medium mb-1">Subcategory</label><select value={formData.subcategory_id} onChange={e => setFormData({...formData, subcategory_id: e.target.value})} className="input-field"><option value="">Select Subcategory</option>{subcategories?.map((s: any) => <option key={s.id} value={s.id}>{s.name}</option>)}</select></div>
                <div><label className="block text-sm font-medium mb-1">Price *</label><input type="number" step="0.01" required value={formData.price} onChange={e => setFormData({...formData, price: e.target.value})} className="input-field" /></div>
                <div><label className="block text-sm font-medium mb-1">Discount Price</label><input type="number" step="0.01" value={formData.discount_price} onChange={e => setFormData({...formData, discount_price: e.target.value})} className="input-field" /></div>
                <div><label className="block text-sm font-medium mb-1">SKU</label><input value={formData.sku} onChange={e => setFormData({...formData, sku: e.target.value})} className="input-field" /></div>
                <div><label className="block text-sm font-medium mb-1">Brand</label><input value={formData.brand} onChange={e => setFormData({...formData, brand: e.target.value})} className="input-field" /></div>
                <div><label className="block text-sm font-medium mb-1">Stock Quantity *</label><input type="number" required value={formData.stock_quantity} onChange={e => setFormData({...formData, stock_quantity: e.target.value})} className="input-field" /></div>
                <div><label className="block text-sm font-medium mb-1">Tags (comma separated)</label><input value={formData.tags} onChange={e => setFormData({...formData, tags: e.target.value})} className="input-field" placeholder="electronics, gadget, etc" /></div>
              </div>
              <div><label className="block text-sm font-medium mb-1">Short Description</label><input value={formData.short_description} onChange={e => setFormData({...formData, short_description: e.target.value})} className="input-field" /></div>
              <div><label className="block text-sm font-medium mb-1">Description</label><textarea rows={3} value={formData.description} onChange={e => setFormData({...formData, description: e.target.value})} className="input-field" /></div>
              <div>
                <label className="block text-sm font-medium mb-1">Images</label>
                <div className="border-2 border-dashed border-dark-200 rounded-lg p-6 text-center">
                  <ImageIcon className="w-8 h-8 text-dark-400 mx-auto mb-2" />
                  <input type="file" multiple accept="image/*" onChange={(e) => setImageFiles(Array.from(e.target.files || []))} className="hidden" id="product-images" />
                  <label htmlFor="product-images" className="text-primary-800 cursor-pointer hover:underline">Click to upload images</label>
                  {imageFiles.length > 0 && <p className="text-sm text-dark-500 mt-2">{imageFiles.length} files selected</p>}
                  {editingProduct && editingProduct.images.length > 0 && (
                    <div className="flex gap-2 mt-3 justify-center">{editingProduct.images.map((img: string, i: number) => (<img key={i} src={img} alt="" className="w-16 h-16 object-cover rounded-lg" />))}</div>
                  )}
                </div>
              </div>
              <div className="flex flex-wrap gap-4">
                <label className="flex items-center gap-2"><input type="checkbox" checked={formData.is_available} onChange={e => setFormData({...formData, is_available: e.target.checked})} /> Available</label>
                <label className="flex items-center gap-2"><input type="checkbox" checked={formData.is_featured} onChange={e => setFormData({...formData, is_featured: e.target.checked})} /> Featured</label>
                <label className="flex items-center gap-2"><input type="checkbox" checked={formData.is_new_arrival} onChange={e => setFormData({...formData, is_new_arrival: e.target.checked})} /> New Arrival</label>
                <label className="flex items-center gap-2"><input type="checkbox" checked={formData.is_best_seller} onChange={e => setFormData({...formData, is_best_seller: e.target.checked})} /> Best Seller</label>
              </div>
              <div className="flex justify-end gap-3 pt-4">
                <button type="button" onClick={closeModal} className="px-4 py-2 border border-dark-200 rounded-lg hover:bg-dark-50 transition-colors">Cancel</button>
                <button type="submit" disabled={saveProduct.isPending} className="btn-primary">{saveProduct.isPending ? 'Saving...' : (editingProduct ? 'Update' : 'Create')}</button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  )
}
