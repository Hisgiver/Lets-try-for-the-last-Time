import { useState } from 'react'
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query'
import { supabase } from '@/lib/supabase'
import { Plus, Pencil, Trash2, X } from 'lucide-react'
import { generateSlug } from '@/lib/utils'
import toast from 'react-hot-toast'
import type { Category } from '@/types'

export default function AdminCategoriesPage() {
  const queryClient = useQueryClient()
  const [isModalOpen, setIsModalOpen] = useState(false)
  const [editingCategory, setEditingCategory] = useState<Category | null>(null)
  const [formData, setFormData] = useState({ name: '', description: '', image_url: '', sort_order: '0', is_active: true })

  const { data: categories } = useQuery({
    queryKey: ['admin-categories'],
    queryFn: async () => {
      const { data } = await supabase.from('categories').select('*').order('sort_order')
      return data || []
    },
  })

  const saveCategory = useMutation({
    mutationFn: async () => {
      const slug = generateSlug(formData.name)
      const data = { ...formData, slug, sort_order: parseInt(formData.sort_order) }
      if (editingCategory) {
        await supabase.from('categories').update(data).eq('id', editingCategory.id)
      } else {
        await supabase.from('categories').insert(data)
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['admin-categories'] })
      toast.success(editingCategory ? 'Category updated' : 'Category created')
      closeModal()
    },
  })

  const deleteCategory = useMutation({
    mutationFn: async (id: string) => {
      await supabase.from('categories').delete().eq('id', id)
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['admin-categories'] })
      toast.success('Category deleted')
    },
  })

  const openModal = (category?: Category) => {
    if (category) {
      setEditingCategory(category)
      setFormData({ name: category.name, description: category.description || '', image_url: category.image_url || '', sort_order: category.sort_order.toString(), is_active: category.is_active })
    } else {
      setEditingCategory(null)
      setFormData({ name: '', description: '', image_url: '', sort_order: '0', is_active: true })
    }
    setIsModalOpen(true)
  }

  const closeModal = () => { setIsModalOpen(false); setEditingCategory(null) }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-bold text-dark-900">Categories</h1>
        <button onClick={() => openModal()} className="btn-primary gap-2"><Plus className="w-4 h-4" /> Add Category</button>
      </div>
      <div className="bg-white rounded-xl border border-dark-100 overflow-hidden">
        <table className="w-full text-sm">
          <thead className="bg-dark-50 text-dark-600"><tr><th className="text-left px-4 py-3">Name</th><th className="text-left px-4 py-3">Slug</th><th className="text-left px-4 py-3">Status</th><th className="text-right px-4 py-3">Actions</th></tr></thead>
          <tbody className="divide-y divide-dark-100">
            {categories?.map((cat: Category) => (
              <tr key={cat.id} className="hover:bg-dark-50">
                <td className="px-4 py-3 font-medium text-dark-900">{cat.name}</td>
                <td className="px-4 py-3 text-dark-500">{cat.slug}</td>
                <td className="px-4 py-3"><span className={`text-xs px-2 py-1 rounded-full ${cat.is_active ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'}`}>{cat.is_active ? 'Active' : 'Inactive'}</span></td>
                <td className="px-4 py-3 text-right">
                  <button onClick={() => openModal(cat)} className="p-1.5 text-dark-400 hover:text-primary-800"><Pencil className="w-4 h-4" /></button>
                  <button onClick={() => deleteCategory.mutate(cat.id)} className="p-1.5 text-dark-400 hover:text-red-500"><Trash2 className="w-4 h-4" /></button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      {isModalOpen && (
        <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl w-full max-w-lg">
            <div className="p-6 border-b border-dark-100 flex justify-between"><h2 className="text-xl font-bold">{editingCategory ? 'Edit' : 'Add'} Category</h2><button onClick={closeModal}><X className="w-5 h-5" /></button></div>
            <form onSubmit={(e) => { e.preventDefault(); saveCategory.mutate() }} className="p-6 space-y-4">
              <div><label className="block text-sm font-medium mb-1">Name *</label><input required value={formData.name} onChange={e => setFormData({...formData, name: e.target.value})} className="input-field" /></div>
              <div><label className="block text-sm font-medium mb-1">Description</label><textarea value={formData.description} onChange={e => setFormData({...formData, description: e.target.value})} className="input-field" /></div>
              <div><label className="block text-sm font-medium mb-1">Image URL</label><input value={formData.image_url} onChange={e => setFormData({...formData, image_url: e.target.value})} className="input-field" /></div>
              <div><label className="block text-sm font-medium mb-1">Sort Order</label><input type="number" value={formData.sort_order} onChange={e => setFormData({...formData, sort_order: e.target.value})} className="input-field" /></div>
              <label className="flex items-center gap-2"><input type="checkbox" checked={formData.is_active} onChange={e => setFormData({...formData, is_active: e.target.checked})} /> Active</label>
              <div className="flex justify-end gap-3 pt-4">
                <button type="button" onClick={closeModal} className="px-4 py-2 border border-dark-200 rounded-lg">Cancel</button>
                <button type="submit" disabled={saveCategory.isPending} className="btn-primary">{saveCategory.isPending ? 'Saving...' : 'Save'}</button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  )
}
